create view VIEW_OPCVM_VAL_PERF_ANNUELLE as
SELECT m.alias,
    m.DAT_IVL,
    v.vl_ivl,
    vd.dat_ivl,
    vd.vl_ivl
  FROM
    (SELECT MIN(dat_ivl) dat_ivl,
      MIN(dat_ivl_deb_an) dat_ivl_deb_an,
      ALIAS
    FROM sc_vl_ngtrend
    GROUP BY ALIAS,
      extract(MONTH FROM dat_ivl),
      extract(YEAR FROM dat_ivl)
    ) m
  JOIN sc_vl_ngtrend v
  ON v.dat_ivl = m.dat_ivl
  AND v.alias  =m.alias
  LEFT JOIN sc_vl_ngtrend vd
  ON vd.dat_ivl=m.dat_ivl_deb_an
  AND vd.alias =m.alias
/

