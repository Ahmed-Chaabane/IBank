create view VIEW_OPCVM_PRTF_VL_LAST as
select distinct
 P.cod_grp,P.cod_prd,P.num_lig,P.cod_val,P.qte_val,P.prx_uni,P.prx_rev,P.cours,P.pied_cou,P.lattente,
P.interet,P.val_bou,P.part_actif,P.cod_isin,P.actif_net,P.vl,P.nbr_action,P.ide_val,
V.alias,V.dat_ivl,V.nbre_act_ivl,V.vl_ivl,V.liquidite,V.dat_comp,V.nbre_jour_ivl,V.ide_opcvm
from sc_prtf_ngtrend P join sc_vl_ngtrend V on p.alias=v.alias and p.dat_prtf=v.dat_ivl
where dat_ivl = 
(select max(dat_ivl) from sc_vl_ngtrend)
/

