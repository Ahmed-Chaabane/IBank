create FUNCTION          "OLD_PORT_RETRO" (P_COD_CPT VARCHAR2,P_VAL_COD_VAL NUMBER,P_DAT_PRT DATE) RETURN NUMBER IS
/*******************Valeurs de retour*****************
    -1  Sens de l'opération non défini
    autrement le n° du dossier
******************************************************/
                                           
cursor PTR is select VAL_COD_VAL,CPT_COD_CPT
              from portefeuille  where 
                    CPT_COD_CPT = NVL(P_COD_CPT,CPT_COD_CPT) and
                    VAL_COD_VAL = NVL(P_VAL_COD_VAL,VAL_COD_VAL) ;
CURSOR EVT(V_COD_VAL NUMBER,V_CPT_COD_CPT VARCHAR2) IS SELECT  COM_BOU_EVT_1,TVA_BOU_MVT_1,COM_BOU_EVT_2,TVA_BOU_MVT_2,
                                                               COM_BOU_EVT_3,TVA_BOU_MVT_3,COM_INT_EVT,TVA_COM_INT_EVT,
                                                              OPE_COD_OPE,QTE_EVT,COU_EVT,DAT_CPT_EVT 

                                                               /* + INDEX(EVENEMENT,EVT_PORT_RETRO_I) */
                                FROM EVENEMENT
                                WHERE COM_COD_CPT = V_CPT_COD_CPT AND
                                      trunc(DAT_CPT_EVT) <= trunc(P_DAT_PRT) AND
                                      VAL_COD_VAL = V_COD_VAL AND
                                      FAM_OPE = 1   AND --Opé Sur Titre
                                      STA_COD_STA != 2 --Annulé
                                      and ( dat_clo_cpt is null or dat_clo_cpt >= p_dat_prt)
                                ORDER BY DAT_CPT_EVT,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'2',997,'12',995,'41',990,'45',980,'47',970,1) desc ;
    v_num_dos Number;
    V_SGN_OPE VARCHAR(30);
    V_QTE_VAL Number;
    V_VAL_ACQ Number;
V_VAL_REA_VAL Number;
V_DAT_DOP_VAL DATE;
    V_CMP_VAL Number;
    V_QTE_BLO number;
    V_COM_VAL number(18,3) := 0;
    V_CPT_MAN varchar2(20);
    V_COD_GRP varchar2(20);
    V_COD_CPT varchar2(20);


BEGIN
  
  select prt_num_dos.nextval into v_num_dos from dual;

   /**Completer le portefeuille rétroactif à partir des evenements*****/
   FOR  CUR_PTR IN PTR LOOP
      V_QTE_VAL := 0;
      V_VAL_ACQ := 0;
      V_QTE_BLO :=0;
      V_VAL_REA_VAL := 0;
      V_DAT_DOP_VAL := Null;
      V_COM_VAL := 0;
      --V_CPT_MAN := NULL;
      ----V_COD_GRP := NULL;
      IF NVL(V_COD_CPT,'-1') != CUR_PTR.CPT_COD_CPT THEN
         BEGIN
          SELECT COD_CPT_MON,COD_GRP INTO  V_CPT_MAN,V_COD_GRP FROM COMPTE WHERE COD_CPT=CUR_PTR.CPT_COD_CPT;
         EXCEPTION
           WHEN OTHERS THEN RETURN -2;
          END;
        V_COd_CPT := CUR_PTR.CPT_COD_CPT;
      END IF;
      FOR CUR_EVT IN EVT(CUR_PTR.VAL_COD_VAL,CUR_PTR.CPT_COD_CPT) LOOP
          SELECT nvl(SGN_OPE,'*') INTO V_SGN_OPE
          FROM OPERATION
          WHERE COD_OPE = CUR_EVT.OPE_COD_OPE;
                      V_COM_VAL := nvl(V_COM_VAL,0) + nvl(CUR_EVT.COM_BOU_EVT_1,0)  + nvl(CUR_EVT.TVA_BOU_MVT_1,0)+ 
                                   nvl(CUR_EVT.COM_BOU_EVT_2,0)  + nvl(CUR_EVT.TVA_BOU_MVT_2,0)+ 
                                   nvl(CUR_EVT.COM_BOU_EVT_3,0)  + nvl(CUR_EVT.TVA_BOU_MVT_3,0)+ 
                                   nvl(CUR_EVT.COM_INT_EVT,0)    + nvl(CUR_EVT.TVA_COM_INT_EVT,0); 
       IF V_SGN_OPE = 'C' THEN
              If CUR_EVT.OPE_COD_OPE IN('90','91','92','93','95','96') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) - CUR_EVT.QTE_EVT;
           Else


             V_QTE_VAL     := V_QTE_VAL + nvl(CUR_EVT.QTE_EVT,0);
             V_VAL_ACQ     := V_VAL_ACQ + (nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             IF V_QTE_VAL != 0 then
                V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
             ELSE
                V_VAL_ACQ := 0; --dépôt derniere opé apres solde négatif
             END IF;
            end if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
          ELSIF V_SGN_OPE = 'D' THEN
           If CUR_EVT.OPE_COD_OPE IN('80','81','82','83','85','86') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) + CUR_EVT.QTE_EVT;
           Else          

             IF V_QTE_VAL != 0 then
                 V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
                 V_VAL_ACQ     := greatest(V_VAL_ACQ - (nvl(CUR_EVT.QTE_EVT,0) * nvl(V_CMP_VAL,0)),0) ;
             ELSE
                V_VAL_ACQ := 0;
             END IF;
             V_QTE_VAL     := V_QTE_VAL - nvl(CUR_EVT.QTE_EVT,0);
            if cur_evt.ope_cod_ope ='2' then
               V_VAL_REA_VAL := V_VAL_REA_VAL + (CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - V_CMP_VAL));
            end if;
            end if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;

          ELSE
             RETURN -1; -- Sense de l'opération non défini
          END IF;

          IF V_QTE_VAL = 0  and CUR_EVT.OPE_COD_OPE  in ('2','4')
            then
                V_COM_VAL  := 0;
          END IF;

      END LOOP;

      IF V_DAT_DOP_VAL IS NOT NULL THEN
          insert into portefeuille_retroactif(QTE_VAL,
                                      QTE_BLO_VAL    ,   
                                      VAL_REA_VAL    ,
                                      COU_ACQ_VAL    ,
                                      COM_VAL        ,
                                      DAT_DOP_VAL    ,  
                                      NUM_DOS        , 
                                      CPT_COD_CPT    , 
                                      VAL_COD_VAL ,
                                      COD_CPt_MAN,
                                      COd_GRP   )  

      values(                         V_QTE_VAL              ,
                                      V_QTE_BLO     ,   
                                      V_VAL_REA_VAL          ,
                                      V_VAL_ACQ              ,
                                      V_COM_VAL              ,
                                      V_DAT_DOP_VAL          ,  
                                      V_NUM_DOS              , 
                                      CUR_PTR.CPT_COD_CPT    , 
                                      CUR_PTR.VAL_COD_VAL   ,
                                      NVL(V_CPT_MAN,CUR_PTR.CPT_COD_CPT),
                                      V_COd_GRP 
                                      );   
    END IF;
   END LOOP; 
   RETURN V_NUM_DOS;     
END;
/

