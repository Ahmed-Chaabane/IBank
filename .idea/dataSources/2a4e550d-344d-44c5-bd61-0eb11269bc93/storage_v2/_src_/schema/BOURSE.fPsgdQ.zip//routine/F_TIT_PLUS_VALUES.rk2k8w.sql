create FUNCTION          "F_TIT_PLUS_VALUES" (P_COD_CPT VARCHAR2,
                       P_TYP_FRAIS IN VARCHAR2, --O oui  N sans frais
                       P_VAL_COD_VAL NUMBER,
                       P_DAT_EVT DATE,
                       P_DAt_TRA DATE,   -- date + heure
                       P_CMP_MOY OUT NUMBER,
                       P_COU_ACQ OUT NUMBER,
                       P_QTE_VAL OUT NUMBER) RETURN NUMBER IS

cursor PTR is select   CPT_COD_CPT,VAL_COD_VAL, VAL_ACT_POR,POR_ID,MNT_INT_COU,MNT_DIV_INT_VAL 
              from portefeuille
              where CPT_COD_CPT = NVL(P_COD_CPT,CPT_COD_CPT) and
                    VAL_COD_VAL = NVL(P_VAL_COD_VAL,VAL_COD_VAL) ;

 CURSOR EVT(V_COD_VAL NUMBER,V_CPT_COD_CPT VARCHAR2) IS
                         SELECT DAT_CPT_EVT,dat_tra_evt,ope_cod_ope
                         NUM_EVT,COM_BOU_EVT_1, TVA_BOU_MVT_1,  
                         COM_BOU_EVT_2, TVA_BOU_MVT_2,COM_BOU_EVT_3, TVA_BOU_MVT_3,  
                         COM_INT_EVT, TVA_COM_INT_EVT ,OPE_COD_OPE,QTE_EVT,COU_EVT
  From
                                /* + INDEX(EVENEMENT,EVT_PORT_RETRO_I) */
                                EVENEMENT
                                WHERE COM_COD_CPT = V_CPT_COD_CPT 
                                      AND VAL_COD_VAL = V_COD_VAL 
                                      AND FAM_OPE = 1    --Opé Sur Titre
                                      AND DAT_TRA_EVT < P_DAT_TRA 
                                      AND STA_COD_STA != 2 --Annulé
                   ---ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'2',997,'12',995,'41',990,'45',980,'47',970,1) desc ;
                   ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'1',997,'12',995,'41',990,'45',980,'47',970,'16',600,1) desc ;
 
 
                                 


    V_NUM_DOS  Number;
    V_SGN_OPE  VARCHAR(30);
    V_QTE_VAL  Number;
    V_VAL_ACQ  Number;
V_VAL_REA_VAL  Number;
V_DAT_DOP_VAL  DATE;
    V_QTE_BLO  Number;
    V_CMP_VAL  Number;
    V_COM_VAL  number(18,3) := 0;
    V_TOT_COM  number:=0;
    V_PAR_COM  Number:=0;
    S_QTE_VAL  Number(12);

BEGIN
  
  

   /**Completer le portefeuille rétroactif à partir des evenements*****/
   FOR  CUR_PTR IN PTR LOOP
      V_QTE_VAL := 0;
      V_VAL_ACQ := 0;
      V_VAL_REA_VAL := 0;
      V_DAT_DOP_VAL := Null;
      V_COM_VAL := 0;
      V_QTE_BLO  :=0;
      FOR CUR_EVT IN EVT(CUR_PTR.VAL_COD_VAL,CUR_PTR.CPT_COD_CPT) LOOP
          SELECT nvl(SGN_OPE,'*') INTO V_SGN_OPE
          FROM OPERATION
          WHERE COD_OPE = CUR_EVT.OPE_COD_OPE;
                      V_COM_VAL :=  nvl(CUR_EVT.COM_BOU_EVT_1,0)  + nvl(CUR_EVT.TVA_BOU_MVT_1,0)+ 
                                   nvl(CUR_EVT.COM_BOU_EVT_2,0)  + nvl(CUR_EVT.TVA_BOU_MVT_2,0)+ 
                                   nvl(CUR_EVT.COM_BOU_EVT_3,0)  + nvl(CUR_EVT.TVA_BOU_MVT_3,0)+ 
                                   nvl(CUR_EVT.COM_INT_EVT,0)    + nvl(CUR_EVT.TVA_COM_INT_EVT,0); 
       IF P_TYP_FRAIS='N' THEN --- san frais
          V_COM_VAL :=0;
       END IF;                            
       IF V_SGN_OPE = 'C' THEN
          V_TOT_COM := NVL(V_TOT_COM,0) + V_COM_VAL;

           If CUR_EVT.OPE_COD_OPE IN('90','91','92','93') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) - CUR_EVT.QTE_EVT;
           Else
             V_QTE_VAL     := V_QTE_VAL + nvl(CUR_EVT.QTE_EVT,0);
             V_VAL_ACQ     := NVL(V_VAL_ACQ,0) + V_COM_VAL +(nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             IF V_QTE_VAL != 0 then
                V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
             ELSE
                V_VAL_ACQ := 0; --dépôt derniere opé apres solde négatif
                V_TOT_COM := 0;
             END IF;
            End if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
          ELSIF V_SGN_OPE = 'D' THEN
     
           If CUR_EVT.OPE_COD_OPE IN('80','81','82','83') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) + CUR_EVT.QTE_EVT;
           Else          

             IF V_QTE_VAL != 0 then
                 V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
                 V_VAL_ACQ     := V_VAL_ACQ  - (nvl(CUR_EVT.QTE_EVT,0) * nvl(V_CMP_VAL,0)) ;
             ELSE
                V_VAL_ACQ := 0;
             END IF;
             S_QTE_VAL := V_QTE_VAL;
             V_QTE_VAL     := V_QTE_VAL - nvl(CUR_EVT.QTE_EVT,0);
               if cur_evt.ope_cod_ope in ('2','17')
                  then
                  V_VAL_REA_VAL := V_VAL_REA_VAL - V_COM_VAL +(CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - V_CMP_VAL));
                end if;
             if cur_evt.ope_cod_ope in ('2','4','17') and S_QTE_VAL > 0 THEN   
                   V_PAR_COM :=  V_TOT_COM * CUR_EVT.QTE_EVT / S_QTE_VAL ;
                   V_TOT_COM := greatest(V_TOT_COM -  V_PAR_COM,0);
             end if;

            End if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;

          ELSE
             RETURN -1; -- Sense de l'opération non défini
          END IF;
         IF V_QTE_VAL = 0  and CUR_EVT.OPE_COD_OPE  in ('2','4','17')
            then
            V_COM_VAL  := 0;
            V_TOT_COM  := 0;
            V_VAL_ACQ  := 0;
         ELSIF V_QTE_VAL = 0 THEN
            V_VAL_ACQ := NVL(V_TOT_COM,0);
            V_TOT_COM := 0;
          END IF; 

      END LOOP;

   END LOOP; 

  P_CMP_MOY := V_CMP_VAL;
  P_COU_ACQ := V_VAL_ACQ;     
  P_QTE_VAL := V_QTE_VAL;
  --message(' dat _tra ='||to_char(p_dat_tra,'dd/mm/yyyy hh24:mi:ss')||' cmp='||v_cmp_val||' qte_avant='||v_qte_val);
  ---message(' dat _tra ='||to_char(p_dat_tra,'dd/mm/yyyy hh24:mi:ss')||' cmp='||v_cmp_val||' qte_avant='||v_qte_val);
   RETURN 0;     
END;
/

