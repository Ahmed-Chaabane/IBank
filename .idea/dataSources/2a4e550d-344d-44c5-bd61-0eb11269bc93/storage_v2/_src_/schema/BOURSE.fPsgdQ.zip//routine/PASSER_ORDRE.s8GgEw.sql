create FUNCTION           "PASSER_ORDRE" (                             p_SEN_ORD In NUMBER,
                               p_DAT_FIN in date,
                               p_QTE_ORD in number,
                               p_QTE_DEV in number,
                               p_NUM_CPT in varchar2,
                               p_COD_VAL in number,
                            p_typ_limite in number,
                                 p_COURS in number,
                               p_USE_CRE in varchar2,
                            p_NAT_INS_OP in number,
                               p_typ_cli in varchar2,
                             p_seq_ordre out varchar2,
                               v_EST_ORD out number,
                                   p_rep out varchar2) 
 Return int Is 

    v_qte_blo number; --qté bloqué
   v_qte_stck number; --qté en stock
    v_qte_enc number; --qté en cours de vente/achat
   v_qte_disp number; --qté disponible
   v_tot_comm number; --total commission
   v_web_nego varchar2(1);
Begin
	p_rep := '';
	
	begin
	select nvl(WEB_NEGOS,'N') into v_web_nego from wc_valeur where cod_val=P_cod_val;
	If v_web_nego='N' then --- valeur n'est pas autorisé sur le web 
	    p_rep := 'Valeur interdite de négociation, Conatater le Bakk Office de l''A..F.C ' ;
      Return -1;	
	end if;
	exception
	when others then 
  p_rep := 'Erreur dans la fiche valeur '||p_cod_val||' '||sqlcode;
        Return -1;	
	end;
	
	
	if(p_NAT_INS_OP = 2) then -- vente, donc recupere ventes en cours
	   v_qte_enc := nvl(RAMENE_QTE_CARNETORDRE(p_NUM_CPT,p_COD_VAL, sysdate,2),0);
	   p_rep := p_rep ||  'vente-qte.enc:' ||v_qte_enc||'-';----
	else -- achats, donc recuperer les soldes
	   p_rep := p_rep ||  'achat-';----
	   v_qte_enc := 0;
	end if;
	v_EST_ORD := RAMENE_STOCK_TITRE(p_NUM_CPT,p_COD_VAL,v_qte_stck,v_qte_blo);
	p_rep := p_rep ||  'qte.stck:' ||v_qte_stck||'-qte.blo:'||v_qte_blo||'-';----
	--- calcul quantié disponible
	v_qte_disp:= v_qte_stck - (v_qte_blo + v_qte_enc);
	p_rep := p_rep ||  'qte.disp:' ||v_qte_disp ||'-qte.ord:' ||p_QTE_ORD||'-' ;
	--- test si qté_ord < qté_disp (cas vente)
	if(p_QTE_ORD > v_qte_disp and p_NAT_INS_OP = 2 and p_typ_cli != '2') then
	      p_rep := 'Qté ordre > Qté disponible';--
        Return -1;
	end if;
	begin
  --- génération de la sequence de l'ordre
  select ANNEE_SEANCE || ltrim(to_char(wc_seq_ordre.nextval, '00000')) into p_seq_ordre  from wc_param_logiciel;        
  
  --- calcul montant operation
  v_EST_ORD := calcul_estim(p_NUM_CPT,p_COD_VAL ,p_typ_limite,p_COURS,p_QTE_ORD,p_NAT_INS_OP,p_typ_cli);
  p_rep := p_rep || 'estim='|| v_EST_ORD||'-'; ----     
  --- insertion de l'ordre
  insert into wc_ordre(ORIGINE,SEN_ORD  ,NUM_ORD    ,DAT_FIN         ,QTE_ORD  ,QTE_EXE,QTE_DEV  ,NUM_CPT  ,COD_VAL  ,TYP_LIMITE  ,COURS  ,USE_CRE  ,DAT_CRE,COD_STA,NAT_INS_OP  ,DAT_DEB       ,EST_ORD  ,COD_STA_TRS,mnt_imp)
  values              ('W'    ,p_SEN_ORD,p_seq_ordre,trunc(p_DAT_FIN),p_QTE_ORD,0      ,p_QTE_DEV,p_NUM_CPT,p_COD_VAL,p_TYP_LIMITE,p_COURS,p_USE_CRE,sysdate,1      ,p_NAT_INS_OP,trunc(sysdate),v_EST_ORD,'45',0);
    ---- actualiser le solde achat
    IF P_SEN_ORD = 1 and p_NAT_INS_OP = '1' THEN -- achat
    	 begin
	       Update WC_COMPTE set SLD_ACH=nvl(SLD_ACH,0) + nvl(abs(v_EST_ORD),0)  Where num_cpt=p_NUM_CPT;
	       EXCEPTION
			   WHEN OTHERS THEN p_rep := p_rep || substr('Err actualisation solde achat (17334) compte N° ='||P_NUM_CPT|| ' '|| sqlcode||' '||sqlerrm,1,1000);
			   Return -1;
       end;
    End if;  
  EXCEPTION
    WHEN OTHERS THEN
        ---p_rep :=  p_rep || 'An error has occurred inserting an order.';
         p_rep :=  p_rep || p_seq_ordre||' '||sqlerrm;
        Return -1;
  END;   
  p_rep :=  p_rep || 'est:' || v_EST_ORD || '-seq:' || p_seq_ordre||'fin';
 Return 50;

END;
/

