create FUNCTION          "DERNIER_COURS" (P_COD_VAL NUMBER,P_DAT_SIT DATE ) RETURN NUMBER IS
  
v_dat_jou  Date;
V_Cou_ref  Number(18,3);
V_typ_val  Varchar2(2);
V_Nominal  number(18,3);

	
begin
	
	
	SELECT TYP_VAL_COD_TYP_VAL ,NOm_VAL Into V_typ_val,V_Nominal from tit_valeur where cod_val=P_cod_val;
	If V_typ_val in ('7','8','9','11') then --- Titre de creance 
  		return  V_nominal;
      
	End if;

	
 Select dat_jou Into v_dat_jou from journee;
 IF TRUNC(P_DAT_SIT) = TRUNC(V_DAT_JOU) THEN
    Begin
      select  COU_REF into  V_Cou_ref from TIT_COURS_JOUR where cod_val=P_cod_val;
   Exception 
      when others then
          select COU_ACT_VAL into v_cou_ref  from tit_valeur  where cod_val=P_COD_VAL;
   End; 
   return( v_cou_ref );
 Else
 	Begin
  select COU_REF into V_Cou_ref 
  from cours 
  where val_cod_val = P_COD_VAL 
       and dat_bou = (select max(dat_bou) 
                      from cours 
                      where   dat_bou <= P_DAT_SIT
                         and  val_cod_val = P_COD_VAL
                         and (nvl(COU_CLO,0) != 0 or nvl(cou_ref,0)!=0));
    
    return(nvl(V_Cou_ref,1));
   exception when others then 
          select COU_ACT_VAL into V_Cou_ref  from tit_valeur  where cod_val=P_COD_VAL;
          return(nvl(V_Cou_ref,1));
   End;
   
   End if;
   

End;
/

