create FUNCTION           "GET_SUIVI" (
 p_sen_ord in number,
 p_nom_uti in varchar2,
  p_num_cpt in varchar2
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
  OPEN liste FOR 
select 
  case when ORIGINE='B' then 'AFC' else ORIGINE || '-' || USE_CRE end as origine,
    NUM_ORD,
    replace(ltrim(rtrim(substr(nvl(MNE_VAL,LIB_VAL),1,30))),' ','.') as LIB_VAL,
    NAT_INS_OP,
    QTE_ORD,
    ---QTE_ORD - nvl(OLD_EXE_JRN,0) as QTE_REST,
    QTE_ORD -  ( nvl(QTE_EXE,0) + nvl(QTE_EXE_JRN,0)) as QTE_REST,
    ord.DAT_FIN,
    lim.lib_typ_lim,
    nvl(ord.cours,0) as cours,
    EST_ORD,
    case when cod_sta_trs = '32' then (select LIB_MOT from wc_motif_rejet
                                        where cod_mot = ord.MOTIF  )
                 else sta.lib_sta end as lib_sta,    
    nvl(OLD_EXE_JRN,0),
    NUM_ORD_BO,
    ord.cod_sta,
    ord.cod_sta_trs,
    nvl(ord.cod_sta_bo,'0'),    
    acc.num_cpt as num_cpt,
    lpad(decode(acc.num_cpt,p_num_cpt,'1',acc.num_cpt),20,'0') as cpt_aff
  from wc_ordre ord, wc_valeur val, wc_statut sta,wc_type_limite lim, wc_det_acces acc 
  where 
   acc.nom_uti= p_nom_uti and 
  ord.num_cpt=acc.num_cpt and 
  sen_ord = p_sen_ord and --- NAT_INS_OP = p_sen_ord and
  (decode(NAT_INS_OP, 4, trunc(ord.DAT_CRE), 6 ,trunc(ord.DAT_CRE), trunc(ord.DAT_FIN)) >= trunc(sysdate) 
       or 
   decode(ord.cod_sta_bo,'32',trunc(ord.DAT_CRE),trunc(ord.DAT_FIN)) >= trunc(sysdate))  and
  qte_ord != qte_exe and 
  ord.cod_val = val.cod_val and 
  ord.cod_sta_trs = sta.cod_sta and   
  ord.typ_limite = lim.cod_typ_lim and 
  nvl(ord.cod_sta_bo,'1') in ('1','32')
  order by cpt_aff,NUM_ORD desc;
  return liste;
end;
/

