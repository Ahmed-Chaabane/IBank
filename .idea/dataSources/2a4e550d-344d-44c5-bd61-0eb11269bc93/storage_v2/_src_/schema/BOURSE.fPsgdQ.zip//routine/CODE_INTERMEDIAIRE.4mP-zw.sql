create FUNCTION          "CODE_INTERMEDIAIRE" RETURN number IS
w_cod_soc number;
BEGIN
  select cod_soc into w_cod_soc from intermediaire where soc_mai_mai=1;
  return(w_cod_soc);
END;
/

