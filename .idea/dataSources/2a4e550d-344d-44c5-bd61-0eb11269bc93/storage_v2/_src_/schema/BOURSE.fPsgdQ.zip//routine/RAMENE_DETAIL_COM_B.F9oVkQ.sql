create PROCEDURE          "RAMENE_DETAIL_COM_B" (w_cod_ope in varchar2,w_typ_tra in varchar2,w_dat_tra in date,
          w_dat_jou in date,
          w_num_evt in number,w_cod_com in number,w_mnt_opr in number,
          w_cod_cpt in varchar2,w_cod_val in NUMBER, x_tot_mnt_com in out number,
          x_tot_mnt_tva in out number,w_flag in varchar2,
          x_err in out number,x_reponse in out varchar2)IS

  cursor c12 is
      select TAU_COM,MNT_COM,TYP_VAL,TYP_TRA,TYP_COM,IDE_PAR_COM,
             COD_COM,COD_TYP_CPT,COD_MAR,MNT_COM_MAX,MNT_COM_MIN,COD_TVA
                 
      from param_commission_bourse
      where cod_com=w_cod_com ;
 
  rec  c12%rowtype;             
  z_typ_cpt  varchar2(2);
  z_typ_tra  varchar2(1);
  x_tau_tva  number;
  z_typ_val  number(4);
  z_cod_mar  varchar2(2);
  z_tau_com  number;
  z_mnt_com  number(18,3);
  z_mnt_tva  number(18,3);

BEGIN 

  ---- E = Enregistrement , O = Ordinaire , B= Bloc
  z_typ_tra := nvl(w_typ_tra,'O');
  ramene_typ_val_typ_mar_com_B(w_cod_val,z_typ_val,z_cod_mar,x_err,x_reponse);
  if x_err is not null then 
    return; 
  end if;
  ramene_typ_compte_com_b(w_cod_cpt,z_typ_cpt,x_err,x_reponse);
 
  if x_err is not null then
    return;
  end if;
  BEGIN
    open c12;
      loop
      fetch c12 into rec;
      exit when c12%notfound;
      z_mnt_com := 0;
      z_mnt_tva := 0;
      IF rec.typ_val= z_typ_val and rec.typ_tra = z_typ_tra and rec.cod_typ_cpt = z_typ_cpt 
         and rec.cod_mar = z_cod_mar then
          if rec.typ_com = 1 --- taux fixe 
             then
             z_mnt_com := w_mnt_opr * nvl(rec.tau_com,0)/1000 ;
             if z_mnt_com < nvl(rec.mnt_com_min,0)
                then
                z_mnt_com := nvl(rec.mnt_com_min,0);
             end if;
             if z_mnt_com > nvl(rec.mnt_com_max,0)
                then
                z_mnt_com := nvl(rec.mnt_com_max,0);
             end if;
          elsif rec.typ_com = 3  --- forfaitaire 
             then
             z_mnt_com := nvl(rec.mnt_com,0);
          elsif rec.typ_com=2  --- tranche
             then
           
            ges_comm_tranche_com_b(rec.cod_com,rec.ide_par_com,
                                   w_mnt_opr,z_mnt_com,x_err,x_reponse);
         
          if x_err is not null then
            return; 
          end if; 
          
          if z_mnt_com < nvl(rec.mnt_com_min,0)then
            z_mnt_com := nvl(rec.mnt_com_min,0);
          end if;
          if z_mnt_com > nvl(rec.mnt_com_max,0) then
            z_mnt_com := nvl(rec.mnt_com_max,0);
          end if;
        end if;
      end if;
      If z_mnt_com !=0 then
         ramene_tau_tva(rec.cod_tva,w_dat_tra,w_cod_cpt,x_tau_tva,x_err,x_reponse);
         if x_err is not null then  return; end if;
      End if;
      z_mnt_tva := nvl(z_mnt_com,0) * x_tau_tva;
      if w_flag ='T' and nvl(z_mnt_com,0)!=0 
         then
         begin
         -- insertion dans la table trace_commission
         insert into trace_commission(num_evt,dat_jou,dat_tra_evt,cod_cpt,
                ben_comm,cod_com,cod_sta,mnt_ope,mnt_com,mnt_tva,ope_cod_ope) values
                (w_num_evt,w_dat_jou,w_dat_tra,w_cod_cpt,
                'B',rec.IDE_PAR_COM,'1',w_mnt_opr, round(nvl(z_mnt_com,0),3),round(nvl(z_mnt_tva,0),3),w_cod_ope);
          --- actualisation du compte
          
         exception
            when others then
                 x_err :=2;
                 x_reponse :='Erreur Rencontrée Lors de l''insertion TRACE_COMM.BOURSE CODE ERR='||sqlcode;
                 return;
         end;
      end if;
      x_tot_mnt_tva := round(nvl(x_tot_mnt_tva,0),3) + round(nvl(z_mnt_tva,0),3);
      x_tot_mnt_com := round(nvl(x_tot_mnt_com,0),3) + round(nvl(z_mnt_com,0),3);  
     end loop;
   close c12; 

  END;

END;
/

