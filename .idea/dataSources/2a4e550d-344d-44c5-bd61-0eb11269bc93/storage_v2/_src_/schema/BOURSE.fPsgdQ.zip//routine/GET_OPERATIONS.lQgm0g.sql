create FUNCTION           "GET_OPERATIONS" (
 p_num_cpt in varchar,
 first in int,
 last in int
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
OPEN liste FOR 
  SELECT DAT_MVT, 
  LIB_OPE, 
  COD_OPE, 
  REF_OPE, 
  COU_MVT, 
  MNT_RUS, 
  TVA_RUS, 
  MNT_CTB, 
  TVA_CTB, 
  COM_INT, 
  TVA_INT, 
  MNT_NET
  FROM
  (SELECT DAT_MVT, LIB_OPE, COD_OPE, REF_OPE, COU_MVT, MNT_RUS, TVA_RUS, MNT_CTB, TVA_CTB, COM_INT, TVA_INT, MNT_NET, ROWNUM r 
	   FROM 
	  (SELECT DAT_MVT, LIB_OPE, COD_OPE, REF_OPE, COU_MVT, MNT_RUS, TVA_RUS, MNT_CTB, TVA_CTB, COM_INT, TVA_INT, MNT_NET
	   FROM WC_MVTS
	   where NUM_CPT = p_num_cpt and COD_STA!='2'
	   ORDER BY DAT_MVT desc, cod_val desc, num_mvt desc)
	   )
  WHERE r BETWEEN first AND last;
     
return liste;
end;
/

