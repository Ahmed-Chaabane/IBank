create FUNCTION           "F_TIT_CALCUL_COMM" (                          P_Cod_ope In Varchar2,
                            P_Cod_cpt In Varchar2,
                            P_Cod_tar in varchar2,
                            P_Cod_val In Number,
                            P_Typ_tra in Varchar2,
                            P_Mnt_ope In Number,
                            P_Dat_tra In Date,
                            P_Dat_jou In Date,
                            P_Simul   In Varchar2,
                            P_Num_evt In Number,
                            P_Com_b   Out Number,
                            P_Tva_b   Out Number,
                            P_Com_i   Out Number,
                            P_Tva_i   Out  Number) Return Number Is  --- S imule  , T ransactionelle "insert" ) IS

   V_MESS   VARCHAR2(500);
    V_ERR   NUMBER(5);
I_TOT_COM   Number(18,3);
I_TOT_TVA   Number(18,3);
B_TOT_COM   Number(18,3);
B_TOT_TVA   Number(18,3);
    B_TOT   Number;
Begin
	
 
	
	 If P_cod_tar is null then -- calcul standard sans tarif spec pour l'ope
      GESTION_COMM_INTER(P_cod_ope,P_num_evt,P_cod_cpt,P_mnt_ope,P_dat_tra,P_dat_jou,I_TOT_COM,I_TOT_TVA,
                         P_Simul,V_err, V_mess);
	 Else
	 	  MOD_GESTION_COMM_INTER(P_cod_ope,P_num_evt,P_cod_cpt,
          P_mnt_ope,P_dat_tra,P_dat_jou,P_cod_tar,I_tot_com,I_tot_tva,P_simul,V_err,V_mess);
   End if; 	
	 	
	IF NVL(V_ERR,0)!=0 THEN
	   Return null;
  END IF;
  If P_Cod_val is not null then
     GESTION_COMM_BOURSE(P_cod_ope,P_cod_cpt,P_typ_tra,P_num_evt,P_COD_VAL,P_mnt_ope,
                              P_dat_tra,P_dat_jou,B_TOT_COM,B_TOT_TVA,P_simul,V_err,V_mess);
	  IF NVL(V_ERR,0) !=0 THEN
		   Return null;
	  END IF;
  End if;
  P_Com_b  := nvl(B_tot_com,0);
  P_Tva_b  := nvl(B_tot_tva,0);
  P_Com_i  := nvl(I_tot_com,0);
  P_Tva_i  := nvl(I_tot_tva,0);
  B_TOT    := P_Com_b + P_Tva_b + P_Com_i + P_Tva_i;
  
  update wc_portefeuille set com_sim_ven = B_TOT where NUM_CPT =P_Cod_cpt and COD_VAL =P_Cod_val;

 Return B_TOT;
END;
/

