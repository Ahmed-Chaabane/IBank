create FUNCTION           "VERIF_H_SEUIL" (                       p_COD_VAL in number,
                         p_cours in number ) Return integer Is
                               
   v_cod_isin varchar(20) := ramene_cod_isin(p_COD_VAL);
   v_seuil_h number;
   v_seuil_b number;
Begin
  begin
    if(v_cod_isin = ' ') then
      return 0;
    end if;
    
    select seuil_haut, seuil_bas into v_seuil_h,v_seuil_b
    from wc_donne_marche 
    where COD_ISIN = v_cod_isin;
    
    if(p_cours < v_seuil_b or p_cours > v_seuil_h) then 
      return 5;
    else
      return -1;
    end if;
  EXCEPTION 
  when no_data_found then 
    return 0;
  when others then
    return 0;
  end;
end;
/

