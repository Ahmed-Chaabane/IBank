create PROCEDURE           "GET_SOLDE" (
 p_num_cpt in number,
 p_pin_cli out varchar, 
 p_SLD_ESP out number,
 p_SLD_SIC out number,
 p_SLD_ACH out number,
 p_CHQ_ENC out number,
 p_con_sic out varchar,
 p_lib_cpt out varchar,
 p_typ_cli out varchar2
)
as
begin
     SELECT
            cpt.PIN_CLI as PIN_CLI,
            NVL(SLD_ESP, 0) AS SLD_ESP,
            NVL(SLD_SIC, 0) AS SLD_SIC,
            NVL(SLD_ACH, 0) AS SLD_ACH,
            NVL(CHQ_ENC, 0) AS CHQ_ENC,
            nvl(CON_SIC,'N'),
            lib_cpt,
            nvl(cli.typ_cli,'9')
    INTO p_pin_cli, p_SLD_ESP, p_SLD_SIC, p_SLD_ACH, p_CHQ_ENC,p_con_sic,p_lib_cpt,p_typ_cli
            FROM WC_COMPTE cpt, wc_client cli
            WHERE cpt.num_cpt = p_num_cpt and 
            cli.pin_cli = cpt.pin_cli;            
end;
/

