create FUNCTION           "RAMENE_COD_ISIN" (                             
                               p_COD_VAL in number) Return varchar Is
   p_cod_isin varchar(20);                         
Begin
  begin
    select cod_isin into p_cod_isin 
    from wc_valeur 
    where cod_val = p_COD_VAL and cod_isin is not null;
  EXCEPTION 
  when no_data_found then 
    return ' ';
  when others then
    return ' ';
  end;
return nvl(p_cod_isin,' ') ;
end;
/

