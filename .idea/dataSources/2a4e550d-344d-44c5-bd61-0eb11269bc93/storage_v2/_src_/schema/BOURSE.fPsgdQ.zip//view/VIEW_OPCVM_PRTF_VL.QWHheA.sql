create view VIEW_OPCVM_PRTF_VL as
SELECT distinct 
    P.actif_net,
    V.alias,
    V.dat_ivl,
    V.vl_ivl    
  FROM sc_prtf_ngtrend P
  JOIN sc_vl_ngtrend V
  ON p.alias    =v.alias
  AND p.dat_prtf=v.dat_ivl
/

