create PROCEDURE           "GET_UPDATED_SOLDES" (
 p_num_cpt in number,
 p_SLD_ESP out number,
 p_SLD_SIC out number,
 p_SLD_ACH out number,
 p_CHQ_ENC out number
)
as
begin
     SELECT
            NVL(SLD_ESP, 0) AS SLD_ESP,
            NVL(SLD_SIC, 0) AS SLD_SIC,
            NVL(SLD_ACH, 0) AS SLD_ACH,
            NVL(CHQ_ENC, 0) AS CHQ_ENC
    INTO p_SLD_ESP, p_SLD_SIC, p_SLD_ACH, p_CHQ_ENC   
            FROM WC_COMPTE
            WHERE num_cpt = p_num_cpt;
end;
/

