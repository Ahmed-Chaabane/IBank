create FUNCTION          "F_TIT_VAL_PRTF" (P_num_dos in number,P_cod_cpt in varchar2,P_dat_sit in date,P_total out number,
                              P_sicav out number)    Return Number IS
 

Cursor c_prtf is    Select  val_cod_val,qte_val from portefeuille_retroactif  Where P_num_dos is not null and
                     Num_dos = P_num_dos and qte_val != 0  
 Union
         Select val_cod_val,qte_val from portefeuille   Where P_num_dos is  null and
                     Cpt_cod_cpt = P_cod_cpt  and qte_val != 0 ;
      
v_cou_clo   Number(18,3);
v_cou_ref   Number(18,3);
w_typ_val   Number(18,3);
  T_sicav   Number(18,3);
  T_total   Number(18,3);
V_dat_jou   Date;
    V_rep   Number(4);
 

BEGIN
  Select dat_jou into V_dat_jou from journee;
  For v_prtf in c_prtf
  Loop
     begin
     select TYP_VAL_COD_TYP_VAL  into w_typ_val  from tit_valeur where
            cod_val=v_prtf.val_cod_val;
     exception when others then null;
     end;
     V_rep := F_TIT_DERNIER_COURS(v_prtf.val_cod_val,P_DAT_SIT,V_dat_jou,V_cou_clo,V_cou_ref);
     if w_typ_val in ('6','10')
        then
        T_sicav := nvl(T_sicav,0) + (V_cou_clo * v_prtf.qte_val);
     End if;
        T_total := nvl(T_total,0) + (V_cou_clo * v_prtf.qte_val); 
 
 end loop;

   P_total := nvl(T_total,0); 
   P_sicav := nvl(T_sicav,0);
   Return 0;
 exception
  when others then return -1;
END;
/

