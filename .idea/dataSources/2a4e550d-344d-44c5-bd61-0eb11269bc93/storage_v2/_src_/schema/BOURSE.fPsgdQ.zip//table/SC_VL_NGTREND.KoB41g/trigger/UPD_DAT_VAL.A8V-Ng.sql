create trigger UPD_DAT_VAL
    before insert
    on SC_VL_NGTREND
    for each row
DECLARE
BEGIN
  :NEW.dat_ivl_mois := date_out_month(add_months(:NEW.dat_ivl, -1),:NEW.alias);
  :NEW.dat_ivl_an := date_out_month(add_months(:NEW.dat_ivl, -12),:NEW.alias);
  if extract(day from :NEW.dat_ivl)=1 and extract(month from :NEW.dat_ivl)=1 then
    :NEW.dat_ivl_deb_an := date_in_month('01/01'||(extract(year from :NEW.dat_ivl)-1),:NEW.alias);
  else
    :NEW.dat_ivl_deb_an := date_in_month('01/01'||(extract(year from :NEW.dat_ivl)),:NEW.alias);
  end if;
  :NEW.dat_ivl_veille := date_in_month(:NEW.dat_ivl-1,:NEW.alias);
  :NEW.dat_ivl_5ans := date_out_month(add_months(:NEW.dat_ivl,-60),:NEW.alias);
END;
/

