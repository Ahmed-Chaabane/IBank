create TYPE "SYS_PLSQL_498477_45_1"                                                                                                                                                             as table of PARTAGE."SYS_PLSQL_498477_9_1";
/

