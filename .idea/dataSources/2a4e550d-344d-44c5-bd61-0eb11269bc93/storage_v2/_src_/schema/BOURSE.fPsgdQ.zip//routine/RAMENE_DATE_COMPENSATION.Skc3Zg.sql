create FUNCTION RAMENE_DATE_COMPENSATION (V_JOUR IN DATE) RETURN DATE IS

jour date;
nbr_jou Number := 2;

BEGIN
 jour := V_JOUR;

  while nbr_jou != 0
   Loop
     While EST_FERIE(JOUR + 1)= TRUE  
         Loop
           jour := JOUR + 1;
         End loop;
           jour := JOUR + 1;
     NBR_JOU := NBR_JOU - 1;
   End loop;
 RETURN (JOUR  );
END;
/

