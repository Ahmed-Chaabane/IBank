create PROCEDURE          "RAMENE_TYP_VAL_TYP_MAR_COM_B" (w_cod_val in NUMBER,
                x_typ_val out number,x_cod_mar out varchar2,x_err out number,x_reponse out char) IS
BEGIN

 select car_val,mar_cod_mar  into x_typ_val,x_cod_mar 
 from tit_valeur
 where Cod_val=w_cod_val;
 Exception
   when no_data_found then
    x_err:=1;
    x_reponse:='Type Valeur Inexistant  - Code Valeur='||ltrim(rtrim(w_cod_val));

   When too_many_rows then 
    x_err:=1;
    x_reponse:='Valeur duppliqué  - Code Valeur,N° Evt='||ltrim(rtrim(w_cod_val));


END;
/

