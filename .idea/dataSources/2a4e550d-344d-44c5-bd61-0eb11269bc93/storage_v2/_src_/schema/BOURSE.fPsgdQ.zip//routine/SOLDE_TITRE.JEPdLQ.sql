create FUNCTION          "SOLDE_TITRE" (P_COD_CPT IN VARCHAR2 ) Return Number Is
CURSOR C IS SELECT val_cod_val,qte_val FROM PORTEFEUILLE WHERE CPT_COD_CPT = P_COD_CPT AND vAL_COd_VAL IN
                         (Select cod_val 
                          from Valeur 
                          Where CAT_VAl='A' );
 
V_dat_jou date;
w_cours number;
SOL_TIT number;

BEGIN
   select dat_jou into V_dat_jou from journee;
   FOR V IN C LOOP
    BEGIN
        select COU_CLO into w_cours 
        from cours 
        where val_cod_val = V.val_cod_val 
            and dat_bou = (select max(dat_bou) 
                           from cours 
                           where   dat_bou <= V_dat_jou
                              and  val_cod_val = v.val_cod_val);
        SOL_TIT := nvl(SOL_TIT,0) + nvl(w_cours*v.qte_val,0);
        exception when others then 
          select COU_ACT_VAL into w_cours 
          from tit_valeur   where cod_val=v.val_cod_val;

          SOL_TIT := nvl(SOL_TIT,0) + nvl(w_cours*v.qte_val,0);
    END;
   END LOOP;
   return nvl(SOL_TIT,0);
END;
/

