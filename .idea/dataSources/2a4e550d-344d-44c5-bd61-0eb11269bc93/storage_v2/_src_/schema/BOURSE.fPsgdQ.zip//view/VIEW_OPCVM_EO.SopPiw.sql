create view VIEW_OPCVM_EO as
SELECT distinct 
    P.cod_val
  FROM sc_prtf_ngtrend P
  where NUM_SEQ=165
/

