create procedure annul_commission (w_dat_jou in date,w_cod_ope in varchar2,NN_num_evt in number,
                            w_num_evt in number, w_flag in varchar2,
                            w_ben_com in varchar2, x_err in out number,x_reponse out char) IS

  cursor c1 is select *  from trace_commission where num_evt=w_num_evt and cod_sta!='2'
        and ben_comm in (nvl(w_ben_com,'I'),nvl(w_ben_com,'B'));
  rec   c1%rowtype;

BEGIN
  
  open c1;
  loop
  BEGIN
   fetch c1 into rec;
   exit when c1%notfound;
   if w_flag='S'
      then
      update trace_commission set cod_sta='2' where num_evt=rec.num_evt and ben_comm=rec.ben_comm
             and cod_com=rec.cod_com;
   else  -- modifier
     insert into trace_commission(NUM_EVT,DAT_JOU,COD_CPT,BEN_COMM,COD_COM,COD_STA,
                 MNT_OPE,MNT_COM,MNT_TVA,OPE_COD_OPE,DAT_TRA_EVT) values
                 (NN_NUM_EVT,w_DAT_JOU,rec.COD_CPT,rec.BEN_COMM,
                  rec.COD_COM,1,0,-rec.MNT_COM,-rec.MNT_TVA,w_cod_ope,rec.DAT_TRA_EVT);



   end if;
     Exception
      when others then
      x_reponse :='Err Rencontrée Lors de l''annulation Mvt='||ltrim(rtrim(to_char(w_num_evt)))||' CODE ERR='||sqlcode;
      x_err := 2;
       

  END;

  end loop;
END;

/

