create FUNCTION           "GET_CARNET_ORDRES" (
 p_num_cpt in varchar
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
  OPEN liste FOR 
  select 
  case when ORIGINE='B' then 'AFC' else ORIGINE || '-' || USE_CRE end as origine,
    NUM_ORD,
    substr(nvl(MNE_VAL,LIB_VAL),1,30) as MNE_VAL,
    NAT_INS_OP,
    QTE_ORD,
---    QTE_ORD - nvl(OLD_EXE_JRN,0) as QTE_REST,
     QTE_ORD -  ( nvl(old_QTE_EXE,0) + nvl(QTE_EXE_JRN,0)) as QTE_REST,
 
    DAT_FIN,
    lim.lib_typ_lim,
    nvl(ord.cours,0) as cours,
    EST_ORD,
    case when cod_sta_trs = '32' then (select LIB_MOT from wc_motif_rejet
                                        where cod_mot = ord.MOTIF  )
                 else sta.lib_sta end as lib_sta,
    nvl(OLD_EXE_JRN,0), 
    NUM_ORD_BO,
    ord.cod_sta,
    ord.cod_sta_trs,
    nvl(ord.cod_sta_bo,'0')
  from wc_ordre ord, wc_valeur val, wc_statut sta,wc_type_limite lim
  where ord.num_cpt=p_num_cpt and 
 qte_ord != qte_exe and 
  ord.cod_val = val.cod_val and 
  ord.cod_sta_trs = sta.cod_sta and   
  ord.typ_limite = lim.cod_typ_lim and 
  nvl(ord.cod_sta_bo,'1') in ('1','32')
  and   decode(ord.cod_sta,'3',trunc(DAT_CRE)-1,'4',trunc(DAT_CRE)-1,trunc(dat_fin)) >= trunc(sysdate) 
and 
  (decode(NAT_INS_OP, 4, trunc(DAT_CRE), 6 ,trunc(DAT_CRE), trunc(DAT_FIN)) >= trunc(sysdate) 
or 
   nat_ins_op not in ('4','6') and  decode(cod_sta_bo,'32',trunc(DAT_CRE),trunc(DAT_FIN)) >= trunc(sysdate))


  order by NUM_ORD desc;
  return liste;
end;
/

