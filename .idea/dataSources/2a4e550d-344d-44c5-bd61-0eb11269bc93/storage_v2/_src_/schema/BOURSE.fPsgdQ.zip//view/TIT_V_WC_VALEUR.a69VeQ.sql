create view TIT_V_WC_VALEUR as
select 

COD_VAL ,            
MNE_VAL ,            
LIB_VAL  ,           
TYP_VAL  ,           
CAT_VAL  ,           
ADM_COT  ,           
COD_ISIN ,           
ORD_AFF  ,           
DER_COU  ,           
COD_MAR  ,           
CAR_VAL   ,          
DAT_FIN_NEG ,        
WEB_NEGOS   ,        
LIQUIDITE            
 from   wc_valeur@wc_afc

/

