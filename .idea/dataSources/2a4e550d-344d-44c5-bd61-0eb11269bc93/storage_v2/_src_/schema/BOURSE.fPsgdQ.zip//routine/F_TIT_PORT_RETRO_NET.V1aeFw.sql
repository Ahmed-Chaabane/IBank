create FUNCTION          "F_TIT_PORT_RETRO_NET" (P_NUM_LOT IN OUT NUMBER,
                                  P_COD_CPT VARCHAR2,
                                  P_COD_VAL NUMBER,
                                  P_DAT_PRT DATE) RETURN NUMBER IS
 
    V_POSITION  DATE ;  --- historique situation portfeuille par defaut 01/01/1990                                           
cursor PTR is select   CPT_COD_CPT,VAL_COD_VAL 
              from portefeuille
              where 
                    CPT_COD_CPT = NVL(P_COD_CPT,CPT_COD_CPT) and
                    VAL_COD_VAL = NVL(P_COD_VAL,VAL_COD_VAL) 
               order by cpt_cod_cpt;


CURSOR EVT(V_COD_VAL NUMBER,V_CPT_COD_CPT VARCHAR2) IS SELECT  COM_BOU_EVT_1, TVA_BOU_MVT_1,  
                                    COM_BOU_EVT_2, TVA_BOU_MVT_2,COM_BOU_EVT_3, TVA_BOU_MVT_3,  
                                    COM_INT_EVT, TVA_COM_INT_EVT ,OPE_COD_OPE,DAT_CPT_EVT,QTE_EVT,COU_EVT


                            From /* + INDEX(EVENEMENT,EVT_PORT_RETRO_I) */
                                 EVENEMENT
                                WHERE COM_COD_CPT = V_CPT_COD_CPT 
                                      and VAL_COD_VAL = V_COD_VAL 
                                      and FAM_OPE = 1   --Opé Sur Titre
                                      and ( (trunc(DAT_CPT_EVT) > V_POSITION and trunc(DAT_CPT_EVT) <= trunc(P_DAT_PRT)) Or
                                        trunc(P_DAT_PRT) < V_POSITION and trunc(DAT_CPT_EVT) <= trunc(P_DAT_PRT) )
                                      and STA_COD_STA != 2 --Annulé
                                      and ( dat_clo_cpt is null or trunc(dat_clo_cpt) >= trunc(p_dat_prt))
                                ---ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'2',997,'12',995,'41',990,'45',980,'47',970,1) desc ;
                                ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'1',997,'12',995,'41',990,'45',980,'47',970,'16',600,1) desc ;
     v_num_dos  Number;
     V_SGN_OPE  VARCHAR(30);
     V_QTE_VAL  Number;
     V_VAL_ACQ  Number;
 V_VAL_REA_VAL  Number;
 V_DAT_DOP_VAL  DATE;
     V_QTE_BLO  Number;
     V_CMP_VAL  Number;
     V_COM_VAL  Number(18,3) := 0;
     V_CPT_MAN  VARCHAR2(20);
     V_COD_GRP  VARCHAR2(20);
     V_COD_CPT  VARCHAR2(20);
       V_RECUP  VARCHAR2(1);
       V_HISTO  boolean;
   V_RECUP_PTR  boolean :=FALSE;
    V_NEW_LINE  boolean := false;
 V_DAT_CLO_CPT  DATE;
     V_TOT_COM  NUMBER:=0;
     S_QTE_VAL  NUMBER;
     V_PAR_COM  NUMBER;

BEGIN
   select dat_hist_evt into V_POSITION from journee;
  select prt_num_dos.nextval into v_num_dos from dual;
  If P_Num_lot is null then 
  	 P_num_lot := v_num_dos;
  	 End if;
 if p_dat_prt >= V_POSITION then
    V_HISTO := true;
 end if;


   /**Completer le portefeuille rétroactif à partir des evenements*****/
   FOR  CUR_PTR IN PTR LOOP

      V_QTE_VAL := 0;
      V_VAL_ACQ := 0;
      V_CMP_VAL := 0;
      V_VAL_REA_VAL := 0;
      V_DAT_DOP_VAL := Null;
      V_COM_VAL  := 0;
      V_QTE_BLO  :=0;
      V_TOT_COM  :=0;
      --W_TOT_COM  :=0;
      
      IF NVL(V_COD_CPT,'-1') != CUR_PTR.CPT_COD_CPT THEN
         BEGIN        
          SELECT DAT_CLO_CPT,COD_CPT_MON,COD_GRP INTO  V_DAT_CLO_CPT,V_CPT_MAN,V_COD_GRP FROM COMPTE WHERE COD_CPT=CUR_PTR.CPT_COD_CPT;
         EXCEPTION
           WHEN OTHERS THEN RETURN -2;
         END;
         V_COd_CPT := CUR_PTR.CPT_COD_CPT;


         if v_histo  then 
          IF NVL(V_DAT_CLO_CPT,P_DAT_PRT) >= P_DAT_PRT THEN   

            BEGIN

            insert into portefeuille_retroactif(QTE_VAL,QTE_BLO_VAL,VAL_REA_VAL,COU_ACQ_VAL,COM_VAL,DAT_DOP_VAL,NUM_DOS,CPT_COD_CPT,VAL_COD_VAL,COD_CPT_MAN,COD_GRP,POR_ID) 
              SELECT  QTE_VAL, QTE_BLO_VAL , VAL_REA_VAL, COU_ACQ_VAL,0, DAT_DOP_VAL,V_NUM_DOS ,CUR_PTR.CPT_COD_CPT,COD_VAL,NVL(V_CPT_MAN,CUR_PTR.CPT_COD_CPT),V_COD_GRP ,P_num_LOT  
                      FROM     TIT_POSITION_TITRE_NET WHERE COD_CPT=CUR_PTR.CPT_COD_CPT  AND COD_VAL = NVL(P_COD_VAL,COD_VAL); 
 
              EXCEPTION
               WHEN OTHERS THEN RETURN -25;
              END;
        END IF;
        end if;
      END IF;
      V_RECUP := 'N';   
      V_NEW_LINE := TRUE;
      FOR CUR_EVT IN EVT(CUR_PTR.VAL_COD_VAL,CUR_PTR.CPT_COD_CPT)
          LOOP
           IF V_HISTO and V_RECUP='N' THEN
             V_RECUP := 'O';
             V_NEW_LINE := FALSE;
             BEGIN
             --- initialisation du stco a partir de l'historique
----            age (' dossier='||v_num_dos||'  init valeur= '||CUR_PTR.VAL_COD_VAL||' V_RECUP='||V_RECUP);
---            Message (' init valeur= '||CUR_PTR.VAL_COD_VAL||' V_RECUP='||V_RECUP);


             SELECT  QTE_VAL, QTE_BLO_VAL , VAL_REA_VAL, COU_ACQ_VAL,0, DAT_DOP_VAL ,NVL(COM_VAL,0) INTO 
                       V_QTE_VAL, V_QTE_BLO , V_VAL_REA_VAL, V_VAL_ACQ, V_COM_VAL, V_DAT_DOP_VAL,V_TOT_COM FROM
                       TIT_POSITION_TITRE_NET WHERE COD_CPT=CUR_PTR.CPT_COD_CPT AND COd_VAL=CUR_PTR.VAL_COD_VAL;
                 --message('total commission recuper='||v_tot_com);
                -- message('total commission recuper='||v_tot_com);
              IF V_QTE_VAL != 0 THEN
                 V_CMP_VAL := V_VAL_ACQ/V_QTE_VAL;
              END IF;
              EXCEPTION
               WHEN NO_DATA_FOUND THEN   V_NEW_LINE := TRUE;
               WHEN OTHERS THEN RETURN -25;
              END;
          
          END IF;

          SELECT nvl(SGN_OPE,'*') INTO V_SGN_OPE     FROM OPERATION  WHERE COD_OPE = CUR_EVT.OPE_COD_OPE;

                      V_COM_VAL := nvl(CUR_EVT.COM_BOU_EVT_1,0)  + nvl(CUR_EVT.TVA_BOU_MVT_1,0)+ 
                                    nvl(CUR_EVT.COM_BOU_EVT_2,0)  + nvl(CUR_EVT.TVA_BOU_MVT_2,0)+ 
                                    nvl(CUR_EVT.COM_BOU_EVT_3,0)  + nvl(CUR_EVT.TVA_BOU_MVT_3,0)+ 
                                    nvl(CUR_EVT.COM_INT_EVT,0)    + nvl(CUR_EVT.TVA_COM_INT_EVT,0); 

       IF V_SGN_OPE = 'C' THEN
          V_TOT_COM := NVL(V_TOT_COM,0) + V_COM_VAL;        
          If CUR_EVT.OPE_COD_OPE IN('90','91','92','93','95','96') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) - CUR_EVT.QTE_EVT;
          Else
             V_QTE_VAL     := V_QTE_VAL + nvl(CUR_EVT.QTE_EVT,0);

             V_VAL_ACQ     := V_VAL_ACQ + V_COM_VAL +(nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
            
             IF V_QTE_VAL != 0 then
                V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
             ELSE
                V_VAL_ACQ := 0; --dépôt derniere opé apres solde négatif
                V_TOT_COM := 0;
             END IF;
            End if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
   ELSIF V_SGN_OPE = 'D' THEN
     
            If CUR_EVT.OPE_COD_OPE IN('80','81','82','83','85','86') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) + CUR_EVT.QTE_EVT;
           Else          
             IF V_QTE_VAL != 0 then
                 V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
                 V_VAL_ACQ     := greatest(V_VAL_ACQ  - (nvl(CUR_EVT.QTE_EVT,0) * nvl(V_CMP_VAL,0)),0) ;
             ELSE
                 V_VAL_ACQ := 0;
             END IF;
             S_QTE_VAL     := V_QTE_VAL ;
             V_QTE_VAL     := V_QTE_VAL - nvl(CUR_EVT.QTE_EVT,0);
            
             if cur_evt.ope_cod_ope in ('2','17') THEN   
                V_VAL_REA_VAL := V_VAL_REA_VAL - V_COM_VAL +(CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - V_CMP_VAL));
             end if;
             if cur_evt.ope_cod_ope in ('2','4','17') and S_QTE_VAL > 0 THEN   
                   V_PAR_COM :=  V_TOT_COM * CUR_EVT.QTE_EVT / S_QTE_VAL ;
                   V_TOT_COM := greatest(V_TOT_COM -  V_PAR_COM,0);
             end if;
            End if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;

          ELSE
             RETURN -1; -- Sense de l'opération non défini
          END IF;

         IF V_QTE_VAL = 0  and CUR_EVT.OPE_COD_OPE  in ('2','4','17')
            then
            V_COM_VAL  := 0;
            V_TOT_COM  := 0;
            V_VAL_ACQ  := 0;
         ELSIF V_QTE_VAL = 0 THEN
    --message(' CMP='||V_CMP_VAL||' commiss='|| v_tot_com);
    --message(' CMP='||V_CMP_VAL||' commiss='|| v_tot_com);

            V_VAL_ACQ := NVL(V_TOT_COM,0);
            V_TOT_COM := 0;
          END IF;  
      --message(' date='||to_char(CUR_EVT.DAT_CPT_EVT,'dd/mm/yyyy')||' CMP='||V_CMP_VAL||' commiss='||' Ope='||CUR_EVT.ope_cod_ope||' commiss='||v_com_val);
      --message(' date='||to_char(CUR_EVT.DAT_CPT_EVT,'dd/mm/yyyy')||' CMP='||V_CMP_VAL||' commiss='||' Ope='||CUR_EVT.ope_cod_ope||' commiss='||v_com_val);
   
      END LOOP;
    --message(' CMP='||V_CMP_VAL||' tot com='|| v_tot_com);
    --message(' CMP='||V_CMP_VAL||' tot_com='|| v_tot_com);
     IF V_DAT_DOP_VAL IS NOT NULL THEN 
        IF V_NEW_LINE THEN -- nouvelle ligne ajouter a la periode 
           ---Message (' new valeur= '||CUR_PTR.VAL_COD_VAL);
           ---Message (' new valeur= '||CUR_PTR.VAL_COD_VAL);


           insert into portefeuille_retroactif(QTE_VAL,
                                      QTE_BLO_VAL    , VAL_REA_VAL    ,COU_ACQ_VAL    ,
                                      COM_VAL        , DAT_DOP_VAL    ,NUM_DOS        , 
                                      CPT_COD_CPT    , VAL_COD_VAL,COD_CPT_MAN,COD_GRP,POR_ID )  

                    values(V_QTE_VAL ,V_QTE_BLO    ,  V_VAL_REA_VAL          ,
                                      V_VAL_ACQ , 0, V_DAT_DOP_VAL ,V_NUM_DOS , 
                                      CUR_PTR.CPT_COD_CPT  , CUR_PTR.VAL_COD_VAL , NVL(V_CPT_MAN,CUR_PTR.CPT_COD_CPT),V_COD_GRP,P_NUM_LOT   
                                       );   
      ELSE  -- ligne ancienne recupére de l'histo
          /*Message (' valeur= '||CUR_PTR.VAL_COD_VAL);
          --Message (' valeur= '||CUR_PTR.VAL_COD_VAL);
          --Message ('set QTE_VAL ='|| v_qte_val||','||
                                      ' QTE_BLO_VAL='||V_QTE_BLO||' ,'||' VAL_REA_VAL='|| V_VAL_REA_VAL||','||'COU_ACQ_VAL  ='|| V_VAL_ACQ||'  ,'||
                                      ' DAT_DOP_VAL  = '||V_DAT_DOP_VAL||' ,'||'COD_CPT_MAN='||V_CPT_MAN||','||' COD_GRP ='||V_COD_GRP);
            --Message ('set QTE_VAL ='|| v_qte_val||','||
                                      ' QTE_BLO_VAL='||V_QTE_BLO||' ,'||' VAL_REA_VAL='|| V_VAL_REA_VAL||','||'COU_ACQ_VAL  ='|| V_VAL_ACQ||'  ,'||
                                      ' DAT_DOP_VAL  = '||V_DAT_DOP_VAL||' ,'||'COD_CPT_MAN='||V_CPT_MAN||','||' COD_GRP ='||V_COD_GRP);
                */
          update portefeuille_retroactif set QTE_VAL = v_qte_val,
                                      QTE_BLO_VAL=V_QTE_BLO , VAL_REA_VAL= V_VAL_REA_VAL    ,COU_ACQ_VAL  =V_VAL_ACQ  ,
                                      DAT_DOP_VAL  = V_DAT_DOP_VAL ,COD_CPT_MAN=NVL(V_CPT_MAN,CUR_PTR.CPT_COD_CPT),COD_GRP =V_COD_GRP
                         Where num_dos = v_num_dos and cpt_cod_cpt= CUR_PTR.CPT_COD_CPT 
                               and val_cod_val =CUR_PTR.VAL_COD_VAL ;


                                       
      END IF;
     ENd IF;



   END LOOP; 
   RETURN V_NUM_DOS;     
END;
/

