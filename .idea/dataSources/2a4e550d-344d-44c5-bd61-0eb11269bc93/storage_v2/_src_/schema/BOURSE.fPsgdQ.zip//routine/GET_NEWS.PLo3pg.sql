create FUNCTION           "GET_NEWS" return TYPES.ref_cursor
as
liste types.ref_cursor;
begin

OPEN liste FOR 
  SELECT num_ope, lib_crt, lib_lon
  FROM wc_news
  WHERE trunc(sysdate) between trunc(dat_deb_aff) and trunc(dat_fin_aff)
        and cod_sta != '2'
  ORDER BY ord_aff;
     
return liste;
end;
/

