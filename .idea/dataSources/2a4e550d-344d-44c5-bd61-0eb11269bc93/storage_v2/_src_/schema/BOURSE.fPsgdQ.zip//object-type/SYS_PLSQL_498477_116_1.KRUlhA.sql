create TYPE "SYS_PLSQL_498477_116_1"                                                                                                                                                             as table of PARTAGE."SYS_PLSQL_498477_53_1";
/

