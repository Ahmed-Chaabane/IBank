create PROCEDURE          "RAMENE_SOLDE_ESPECE" (W_cod_cpt in varchar2,W_solde out number,w_dispo out number,
                              V_COD_COM out varchar2, V_COD_GES out varchar2) IS
BEGIN
  select nvl(sol_esp_cpt,0) ,nvl(sol_esp_cpt,0) - nvl(sol_non_cpt,0),cod_com,
         tie_cod_cli_ges
          
         into w_solde,w_dispo,V_COD_COM, V_COD_GES
         from compte where cod_cpt= W_cod_cpt;
END;
/

