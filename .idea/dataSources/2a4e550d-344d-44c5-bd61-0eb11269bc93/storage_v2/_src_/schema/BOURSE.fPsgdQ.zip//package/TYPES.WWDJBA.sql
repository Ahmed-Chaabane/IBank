create PACKAGE           "TYPES" as
  TYPE ref_cursor IS REF CURSOR;
end;
/

