create PACKAGE "WEB" AS 

  TYPE WEB_VL IS RECORD 
  ( 
    OPCVM VARCHAR2(30),
    DATE_VL DATE,
    VL NUMBER(13,3),
    DATE_VL_AVANT DATE,
    VL_AVANT NUMBER(13,3)
  );  
  
  TYPE WEB_VL_SET 
    IS TABLE OF WEB_VL ;
    
  TYPE WEB_ACTIF IS RECORD 
  ( 
    OPCVM VARCHAR2(30),
    DATE_ACTIF DATE,
    ACTIF_NET NUMBER(13,3), -- Total actif
    BT NUMBER(13,3), -- Bons du Tresor
    ACT NUMBER(13,3), -- Actions
    EMP NUMBER(13,3), -- Emprunts oblig
    OPCV NUMBER(13,3), -- autres opcvm
    PLAC NUMBER(13,3) -- Placements
  );  
  TYPE WEB_ACTIF_SET 
    IS TABLE OF WEB_ACTIF ;
    
  FUNCTION FN_VL RETURN WEB_VL_SET pipelined;

  FUNCTION FN_ACTIF RETURN WEB_ACTIF_SET pipelined;

END WEB;
/

