create view V_FSI_WC_DONNE_MARCHE as
select COD_ISIN, DERN_COU ,   SEUIL_HAUT,  SEUIL_BAS, LIM_ACH,
 LIM_VEN, STATUT, NUM_SEQ From wc_donne_marche@ldb_fsi
/

