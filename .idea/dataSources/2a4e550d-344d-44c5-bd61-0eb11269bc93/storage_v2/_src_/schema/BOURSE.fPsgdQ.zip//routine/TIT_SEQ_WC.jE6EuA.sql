create FUNCTION TIT_SEQ_WC Return Number Is

V_Num_ope number(25);

BEGIN
 select wc_seq_protocole.nextval@WC_AFC Into V_Num_ope from dual;
   return V_Num_ope;
END;

/

