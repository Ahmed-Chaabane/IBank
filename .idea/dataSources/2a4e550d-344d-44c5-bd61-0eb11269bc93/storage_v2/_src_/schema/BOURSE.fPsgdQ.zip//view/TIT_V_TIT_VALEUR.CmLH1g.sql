create view TIT_V_TIT_VALEUR as
select COD_VAL,MNE_VAL,LIB_VAL,TYP_VAL_COD_TYP_VAL,CAT_VAL,
       ADMI_COT,COD_ISIN,ORD_AFF,COU_ACT_VAL,
	     MAR_COD_MAR,CAR_VAL,DAT_FIN_VAL,web_negos,LIQUIDITE,GRP_VAL,nom_val
	                    From Tit_valeur@ldb_prod
/

