create view TIT_V_WC_ANOMALIE_ORDRE_WEB as
select
 NUM_DOS,
 DAT_JOU,
 COD_CPT,
  COD_VAL,
 NAT_INS_ORD,
 NUM_ORD_WEB,
 COD_STA,
 DAT_FIN,
 DAT_CRE,
 COD_PRG from wc_anomalie_ordre_web@wc_afc
/

