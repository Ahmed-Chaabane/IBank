create FUNCTION           "CREATE_PASSWD" (
 p_mot_pas in varchar2
)
return varchar2
as
l_input RAW(16) := utl_raw.cast_to_raw(nvl(p_mot_pas,' '));
begin

return lower(rawtohex(dbms_obfuscation_toolkit.md5(input=>l_input)));

end;
/

