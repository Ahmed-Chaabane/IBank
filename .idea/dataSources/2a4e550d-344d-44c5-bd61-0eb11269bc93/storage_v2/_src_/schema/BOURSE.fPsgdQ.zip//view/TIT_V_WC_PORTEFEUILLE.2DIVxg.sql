create view TIT_V_WC_PORTEFEUILLE as
select 


 
NUM_CPT  ,--                      NOT NULL VARCHAR2(20)
COD_VAL  ,--                      NOT NULL NUMBER(20)
QTE_VAL     ,--                   NOT NULL NUMBER(12)
QTE_BLO_VAL  ,--                  NOT NULL NUMBER(12)
COU_ACQ      ,--                  NOT NULL NUMBER(18,3)
MNT_COM  ,--                       NOT NULL NUMBER(18,3)
COU_ACQ_NET ,--                   NOT NULL NUMBER(18,3)
VAL_REA_NET    ,--                         NUMBER(18,3)
VAL_REA           ,--                      NUMBER(18,3)
COM_SIM_VEN          --                   NUMBER(18,3)

    From wc_portefeuille@wc_afc

/

