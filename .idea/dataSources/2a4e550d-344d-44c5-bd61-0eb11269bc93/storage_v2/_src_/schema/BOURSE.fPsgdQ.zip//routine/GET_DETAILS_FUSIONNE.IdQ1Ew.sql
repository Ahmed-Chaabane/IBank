create FUNCTION           "GET_DETAILS_FUSIONNE" (
 p_nom_uti in varchar,
 p_cod_val in varchar
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
    OPEN liste FOR 
    select porte.num_cpt,
           cpt.lib_cpt,
           porte.qte_blo_val,
           porte.qte_val, 
           decode(cat_val,'O',val.nominal,nvl(dern_cou,val.der_cou)),
           COU_ACQ
    from wc_valeur val, wc_portefeuille porte, WC_DET_ACCES acc, wc_compte cpt, wc_donne_marche don
    where acc.nom_uti = p_nom_uti and 
      porte.cod_val = p_cod_val and
      val.cod_val = p_cod_val and
      acc.num_cpt = porte.num_cpt and
      acc.num_cpt = cpt.num_cpt and
      val.cod_isin = don.cod_isin (+)
    order by lpad(porte.num_cpt,20,'0');
  return liste;
end;
/

