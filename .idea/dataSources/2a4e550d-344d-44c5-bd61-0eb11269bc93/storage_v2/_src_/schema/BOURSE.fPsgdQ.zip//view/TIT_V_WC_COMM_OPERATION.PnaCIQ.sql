create view TIT_V_WC_COMM_OPERATION as
select 
OPE_COD_OPE ,   ---                NOT NULL VARCHAR2(30)
BEN_COM  ,       --               NOT NULL VARCHAR2(1)
COD_TAR ,        ---               NOT NULL NUMBER(10)
CPT_COD_CPT      ---                             VARCHAR2(20)

From wc_comm_operation@wc_afc
/

