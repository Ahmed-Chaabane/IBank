create view TIT_V_WC_STATUT as
select 

COD_STA   ,                  --   NOT NULL VARCHAR2(5)
LIB_STA   ,                   --  NOT NULL VARCHAR2(50)
LIB_LONG                          ---      VARCHAR2(200)
    From wc_statut@wc_afc

/

