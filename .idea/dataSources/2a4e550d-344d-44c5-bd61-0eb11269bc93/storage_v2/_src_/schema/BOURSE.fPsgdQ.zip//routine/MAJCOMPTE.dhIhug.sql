create PROCEDURE          "MAJCOMPTE" (NumCompte VARCHAR2, Valeur Number, Code_Operation VARCHAR2,
                    Mnt_net Number, Commission Number, Quantite Number, Cours Number,
                    DateOperation Date) IS
       V_COD_TYP_GES  varchar2(15);
           V_COD_CLI  varchar2(20);
       V_COD_TYP_CLI  varchar2(5);
Montant_n_disponible  Number:=0;
           V_MNT_ACH  number(18,3):=0;
           v_cat_val  varchar2(3);
BEGIN
 
Begin
	 Select nvl(cat_val,'A') into v_cat_val  from tit_Valeur Where  cod_val=Valeur;
	 exception
	 when others then v_cat_val :='A'; --- action
End;

 
 
  If Code_Operation = '1' Then
     Begin
  	  if v_cat_val !='S' then 
  	     V_mnt_ach := abs(mnt_net);
  	  End if;
  	  
      Update Portefeuille Set Qte_Val = Qte_Val + Quantite,
                              Cou_acq_val= Cou_acq_val + Cours* Quantite,
                              Com_Val = Com_Val+ Commission      
                          ----DAT_DOP_VAL = DateOperation
      Where Cpt_cod_cpt = NumCompte
      And Val_cod_val = Valeur;

      If Sql%Notfound Then
        Insert Into Portefeuille (QTE_VAL, QTE_BLO_VAL, VAL_REA_VAL, COU_ACQ_VAL,
                                  COM_VAL, DAT_DOP_VAL, MNT_DIV_INT_VAL, MNT_INT_COU, NUM_DOS,
                                  POR_ID, CPT_COD_CPT, VAL_COD_VAL) 
                          Values (Quantite, 0, 0, Quantite*Cours, Commission, DateOperation,
                                  0, 0, Null, null, NumCompte, Valeur);
      End if;
    End;
  Elsif Code_Operation = '2' Then
    if Mnt_net >0
       then
       Montant_n_disponible := Mnt_net;
    end if;
    if v_cat_val='S' then
    	 Montant_n_disponible :=0;
    end if;
    BEGIN
      Select typ_ges_in_cod_typ_ges, tie_cod_cli into  V_COD_TYP_GES,V_COD_CLI    From COMPTE
            Where cod_cpt= NumCompte;
      Select typ_cli_cod_typ_cli into V_COD_TYP_CLI  From tiers 
            where cod_cli = V_COD_CLI;
    END;


    IF V_COD_TYP_GES !='2' and V_COD_TYP_CLI!='2' --- Qte_val >= 0 
       THEN  
       Update Portefeuille Set Qte_Val = Qte_Val - Quantite,
                            Cou_acq_val= Cou_acq_val - (Cou_acq_val*Quantite/decode(Qte_val,0,1,Qte_Val)), 
                            Val_rea_val = nvl(Val_rea_val,0) -  Commission + ( Quantite*Cours - (Quantite*Cou_acq_val/decode(Qte_val,0,1,Qte_Val))),
                            Com_Val = Com_Val+ Commission 
       Where Cpt_cod_cpt = NumCompte And Val_cod_val = Valeur  and (Qte_val - nvl(qte_blo_val,0)) >= Quantite;
       if SQL%NOTFOUND 
          THEN

          raise_application_error(-20000,'Verifiez La Quantité [N°Compte , Valeur ]=['||Numcompte||' , '||to_char(valeur)||']');

       end if;
    ELSE ---  Ex Compte Erreur
       Update Portefeuille Set Qte_Val = Qte_Val - Quantite,
                            Cou_acq_val= Cou_acq_val - (Cou_acq_val*Quantite/decode(Qte_val,0,1,Qte_Val)), 
                            Val_rea_val = nvl(Val_rea_val,0) - Commission+ ( Quantite*Cours - (Quantite*Cou_acq_val/decode(Qte_val,0,1,Qte_Val))),
                            Com_Val = Com_Val+ Commission 
       Where Cpt_cod_cpt = NumCompte And Val_cod_val = Valeur ;
      If Sql%Notfound Then
        Insert Into Portefeuille (QTE_VAL, QTE_BLO_VAL, VAL_REA_VAL, COU_ACQ_VAL,
                                  COM_VAL, DAT_DOP_VAL, MNT_DIV_INT_VAL, MNT_INT_COU, NUM_DOS,
                                  POR_ID, CPT_COD_CPT, VAL_COD_VAL) 
                          Values (Quantite, 0, 0, Quantite*Cours, abs(Commission), DateOperation,
                                  0, 0, Null, null, NumCompte, Valeur);
      End if;

    END IF;
  End If;
        
  Update Compte Set Sol_Esp_Cpt = Sol_Esp_Cpt + Mnt_net , sld_ach = greatest(sld_ach -  v_mnt_ach,0),
         Sol_non_cpt = greatest(nvl(sol_non_cpt,0)  + Montant_n_disponible,0)
         Where cod_cpt = NumCompte;   
END;
/

