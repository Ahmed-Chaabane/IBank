create FUNCTION          "F_TIT_VERIF_INTERDICTION" (P_type in varchar2, --- T titre E espece
                                  P_dat_Jou_deb In Date,
                                  P_dat_jou_fin In date,
                                  P_cod_val In number,
                                  P_sens In varchar2, --- Entrer S sortie  T tous
                                  P_cod_cpt in varchar2,
                                  P_ref_dos out number,
                                  P_dat_deb Out date,
                                  P_dat_fin out date)  return number IS


 
      V_ret  Number(5);
  v_cod_cli varchar2(20);

BEGIN
 If P_cod_cpt is not null then
    begin
      select tie_cod_cli into v_cod_cli from compte where cod_cpt=P_cod_cpt;
    exception
    	when others then null;
    end;
 end if;
 
 IF P_TYPE='T' then
 
   for c1 in (Select num_dos,cod_val,  cod_cpt,dat_fin,dat_deb,sens from tit_interdiction I  
       where typ_aut='T' and cod_sta=1 and cod_cli is null and nvl(cod_cpt,P_cod_cpt )=P_cod_cpt
         union 
       Select num_dos,cod_val,  cod_cpt,dat_fin,dat_deb,sens from tit_interdiction 
       where typ_aut='T' and cod_sta=1 and cod_cli is not null and nvl(cod_cli,v_cod_cli)=v_cod_cli)
       
       Loop
          If nvl(c1.cod_cpt,P_cod_cpt) = P_cod_cpt  and nvl(c1.cod_val,P_cod_val) = P_cod_val and (P_sens =c1.sens or c1.sens='T')
            and (P_dat_jou_deb between  c1.dat_deb and c1.dat_fin or P_dat_jou_fin between  c1.dat_deb and c1.dat_fin or
            P_dat_jou_deb < c1.dat_deb and P_dat_jou_fin > c1.dat_fin)
          	 then
          		 P_ref_dos := c1.num_dos;
          		 P_dat_deb := c1.dat_deb;
          		 P_dat_fin := c1.dat_fin;
          		 Return -1;
          	end if;
          	
           
          
       End Loop;
 ELSE  --- interdiction especes
  
  For c1 in (Select num_dos,cod_cpt,dat_fin,dat_deb,sens from tit_interdiction 
       where typ_aut='E' and cod_sta=1 and cod_cli is null and nvl(cod_cpt,P_cod_cpt )=P_cod_cpt
       union  Select num_dos,cod_cpt,dat_fin,dat_deb,sens from tit_interdiction 
       where typ_aut='E' and cod_sta=1 and cod_cli is not null and nvl(cod_cli,v_cod_cli)=v_cod_cli)
       
  Loop
          If  nvl(c1.cod_cpt,P_cod_cpt) = P_cod_cpt and (P_sens =c1.sens or c1.sens='T')
             and (P_dat_jou_deb between  c1.dat_deb and c1.dat_fin or P_dat_jou_fin between  c1.dat_deb and c1.dat_fin or
            P_dat_jou_deb < c1.dat_deb and P_dat_jou_fin > c1.dat_fin) then
          		 P_ref_dos := c1.num_dos;
          		 P_dat_deb := c1.dat_deb;
          		 P_dat_fin := c1.dat_fin;
          		 Return -1;
          	end if;
          	
           
          
       End Loop;
    	
 END IF;
 Return 0;
END;
/

