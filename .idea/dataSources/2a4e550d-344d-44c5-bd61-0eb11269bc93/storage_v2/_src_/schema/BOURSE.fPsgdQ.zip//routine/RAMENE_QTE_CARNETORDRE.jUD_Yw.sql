create FUNCTION           "RAMENE_QTE_CARNETORDRE" (
 p_num_cpt in varchar,
 p_cod_val in number,
 p_dat_jou in date default sysdate,
 p_nat_ins in integer
)
return int
as
totalQte  number;
v_reste  number;
begin
if p_nat_ins = 1 then  --- achat
        Select nvl(sum(qte_ord - (nvl(qte_exe,0))),0) into totalQte
        From WC_ORDRE  
        Where   Trunc(dat_fin)>= trunc(p_dat_jou) 
            and NUM_CPT = p_num_cpt
            AND COD_VAL=p_cod_val
            and cod_sta ='1'
            and nat_ins_op in (1,3)
            and cod_sta_trs !='32' ;


        Select   nvl(sum(nvl(qte_exe_jrn,0)),0) into v_reste
        From WC_ORDRE  
        Where   Trunc(dat_fin)>= trunc(p_dat_jou) 
            and NUM_CPT = p_num_cpt
            AND COD_VAL=p_cod_val
            and cod_sta ='1'
            and nat_ins_op ='4'
            and cod_sta_trs !='32' ;
else
           
       Select nvl(sum(qte_ord -   (nvl(qte_exe,0))),0)   -    sum(decode(nvl(mnt_imp,0),0,0,nvl(qte_exe_jrn,0)))  into totalQte
              From WC_ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   NUM_CPT = p_num_cpt 
                            AND COD_VAL = P_COD_VAL
                            and cod_sta = '1'
                            and nat_ins_op = 2
                            and cod_sta_trs !='32' ; --- vente 
 

        Select  nvl(sum(qte_exe_jrn),0)   into v_reste
              From WC_ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   NUM_CPT = p_num_cpt 
                            AND COD_VAL=P_COD_VAL
                            and cod_sta in ('1','32')
                            and nat_ins_op = 6 
                            and cod_sta_trs !='32'
                            and nvl(mnt_imp,0)=0
                            and dat_sai_en_bou is not null;  --- annul vente
                            
        Select  nvl(totalQte,0) + nvl(sum(qte_ord -   (nvl(qte_exe,0))),0)   into totalQte
              From WC_ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   num_cpt = p_num_cpt 
                            AND COD_VAL=P_COD_VAL
                            and cod_sta in ('1','32') and nvl(cod_sta_bo,'1')!='4'
                            and nat_ins_op =6
                            and cod_sta_trs !='32'
                            and nvl(mnt_imp,0)=0
                            and dat_sai_en_bou  is null;  --- annul vente*/
            
end if;
return totalQte + v_reste;
end;
/

