create FUNCTION DATE_OUT_MONTH 
(
  DATEIN IN DATE  
, OPCVM IN VARCHAR2  
) RETURN DATE AS 
pragma autonomous_transaction;
dateout date;
BEGIN  
  
  select min(dat_ivl) into dateout from SC_VL_NGTREND where alias=OPCVM and extract(year from dat_ivl) = extract(year from datein) 
    and extract(month from dat_ivl) = extract(month from datein);
  
  RETURN dateout;
  
END DATE_OUT_MONTH;
/

