create FUNCTION           "GET_COMPTES" (
 p_nom_uti in varchar
)
RETURN TYPES.ref_cursor
as
liste types.ref_cursor;
begin
   OPEN liste FOR 
        SELECT 
            cpt.PIN_CLI,
            cpt.NUM_CPT,
            cpt.LIB_CPT,
            NVL(SLD_ESP, 0) AS SLD_ESP,
            NVL(SLD_SIC, 0) AS SLD_SIC,
            NVL(SLD_ACH, 0) AS SLD_ACH,
            NVL(CHQ_ENC, 0) AS CHQ_ENC,
            NVL(SLD_BLO, 0) AS SLD_BLO,
            NVL(SLD_CMP, 0) AS SLD_CMP,
            typ.LIB_CPT AS LIB_TYP_CPT,
            nvl(CON_SIC,'N')
            FROM WC_DET_ACCES acc, WC_COMPTE cpt, WC_TYPE_COMPTE typ
         WHERE 
          acc.nom_uti = p_nom_uti and 
          cpt.num_cpt = acc.num_cpt and 
          typ.TYP_CPT = cpt.TYP_CPT 
         ORDER BY lpad(num_cpt,10);
    RETURN liste;
end;
/

