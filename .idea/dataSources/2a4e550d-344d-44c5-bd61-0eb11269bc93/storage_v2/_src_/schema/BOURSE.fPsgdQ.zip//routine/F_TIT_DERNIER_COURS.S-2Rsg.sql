create FUNCTION          "F_TIT_DERNIER_COURS" (P_COD_VAL IN NUMBER,
                             P_DAT_SIT IN DATE,
                             P_DAT_JOU IN DATE,
                             P_COU_CLO OUT NUMBER,
                             P_COU_REF OUT NUMBER ) RETURN NUMBER IS
v_cou_clo number(18,3);
v_cou_ref number(18,3);
V_typ_val Varchar2(2);
V_Nominal number(18,3);
begin
	
	
	SELECT TYP_VAL_COD_TYP_VAL ,NOm_VAL Into V_typ_val,V_Nominal from tit_valeur where cod_val=P_cod_val;
	If V_typ_val in ('7','8','9','11') then --- Titre de creance 
  		P_COU_CLO :=  V_nominal;
      P_COU_REF :=  V_nominal;
      Return 0;
	End if;
	
 
IF TRUNC(P_DAT_SIT)= TRUNC(P_DAT_JOU) THEN
   Begin
      select cou_clo,COU_REF  into V_cou_clo,V_Cou_ref from TIT_COURS_JOUR where cod_val=P_cod_val;
   Exception 
      when others then
          select COU_ACT_VAL into v_cou_clo  from tit_valeur  where cod_val=P_COD_VAL;
   End;
ELSE
   BEGIN
    select COU_Ref,cou_clo into v_cou_ref,v_cou_clo  from cours  where val_cod_val = P_COD_VAL 
           and dat_bou = (select max(dat_bou) 
                      from cours 
                      where   dat_bou <= trunc(P_DAT_SIT) and 
                              val_cod_val = P_COD_VAL and 
                              (nvl(COU_CLO,0) != 0 or nvl(cou_ref,0)!=0));
    
   exception when others then 
          select COU_ACT_VAL into v_cou_clo  from tit_valeur  where cod_val=P_COD_VAL;

    END;
END IF;
P_COU_CLO :=  V_cou_clo;
P_COU_REF :=  nvl(V_cou_ref,v_cou_clo);
Return 0;
Exception
  when others then return -1;
End;
/

