create FUNCTION           "F_WC_SEQ_ORDRE" return Number
as
 
 v_num_ord number(20);

BEGIN

 select TIT_SEQ_ORD.nextval@LDB_PROD Into v_num_ord from dual;   
 
 return v_num_ord;
end;
/

