create FUNCTION           "GET_OPERE" (
 p_num_cpt in varchar,
 p_cod_ope in varchar,
 p_ref_ope in varchar,
 p_dat_mvt in varchar
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
OPEN liste FOR 
    select 
            LIB_OPE, 
            COU_MVT, 
            MNT_RUS, 
            TVA_RUS, 
            MNT_CTB, 
            TVA_CTB, 
            COM_INT, 
            TVA_INT, 
            MNT_NET 
            from WC_MVTS 
            where  NUM_CPT = p_num_cpt and
                   COD_STA!='2' and
                   COD_OPE = p_cod_ope and --- NOT NULL VARCHAR2(30)
                   REF_OPE = p_ref_ope and --- VARCHAR2(20)
                   DAT_MVT = p_dat_mvt --- NOT NULL DATE
            ORDER BY num_mvt, COD_VAL;
      return liste;
end;
/

