create FUNCTION           "GET_COUNT_OPERATIONS" (
 p_num_cpt in varchar
)
return int
as
totalOp  int;
begin

     SELECT count(DAT_MVT) into totalOp
	   FROM WC_MVTS
	   where NUM_CPT = p_num_cpt and COD_STA!='2';

return totalOp;
end;
/

