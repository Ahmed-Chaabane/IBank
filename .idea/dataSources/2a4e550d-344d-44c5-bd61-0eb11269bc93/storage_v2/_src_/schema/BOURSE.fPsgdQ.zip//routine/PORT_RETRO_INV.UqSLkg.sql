create FUNCTION          "PORT_RETRO_INV" (P_COD_CPT VARCHAR2,P_VAL_COD_VAL NUMBER,P_DAT_PRT DATE) RETURN NUMBER IS
/*******************Valeurs de retour*****************
    -1  Sens de l'opération non défini
    autrement le n° du dossier
******************************************************/
cursor PTR is select CPT_COD_CPT ,VAL_COD_VAL 
              from portefeuille
              where CPT_COD_CPT = NVL(P_COD_CPT,CPT_COD_CPT) and
                    VAL_COD_VAL = NVL(P_VAL_COD_VAL,VAL_COD_VAL) ;


CURSOR EVT(V_COD_VAL NUMBER,V_CPT_COD_CPT VARCHAR2) IS SELECT QTE_EVT,OPE_COD_OPE,COU_EVT ,DAT_CPT_EVT



                                /* + INDEX(EVENEMENT,EVT_PORT_RETRO_I) */
                                FROM EVENEMENT
                                WHERE COM_COD_CPT = V_CPT_COD_CPT AND
                                      VAL_COD_VAL = V_COD_VAL AND
                                      FAM_OPE = 1   AND --Opé Sur Titre
                                      trunc(DAT_CPT_EVT) < trunc(P_DAT_PRT) AND
                                      STA_COD_STA != 2 --Annulé
                                      and ( dat_clo_cpt is null or dat_clo_cpt >= p_dat_prt)
                                ---ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'2',997,'12',995,'41',990,'45',980,'47',970,1) desc ;
                                ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'1',997,'12',995,'41',990,'45',980,'47',970,'16',600,1) desc ;
v_num_dos Number;
V_SGN_OPE VARCHAR(30);
V_QTE_VAL Number;
V_VAL_ACQ Number;
V_VAL_REA_VAL Number;
V_DAT_DOP_VAL DATE;
V_CMP_VAL Number;

BEGIN
  
  select prt_num_dos.nextval into v_num_dos from dual;

  /********Insertion a partir du portefeuille directement*** 
  *********puisque la de derniere opération***************** 
  *********est inférieur de la date de la situation demandée

   /**Completer le portefeuille rétroactif à partir des evenements*****/
   FOR  CUR_PTR IN PTR LOOP
      V_QTE_VAL := 0;
      V_VAL_ACQ := 0;
      V_VAL_REA_VAL := 0;
      V_DAT_DOP_VAL := Null;
      FOR CUR_EVT IN EVT(CUR_PTR.VAL_COD_VAL,CUR_PTR.CPT_COD_CPT) LOOP
          SELECT nvl(SGN_OPE,' ') INTO V_SGN_OPE
          FROM OPERATION
          WHERE COD_OPE = CUR_EVT.OPE_COD_OPE;

          IF V_SGN_OPE = 'C' THEN
             V_QTE_VAL     := V_QTE_VAL + nvl(CUR_EVT.QTE_EVT,0);
             V_VAL_ACQ     := V_VAL_ACQ + (nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             IF V_QTE_VAL != 0 then
                V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
             END IF;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;

 





          ELSIF V_SGN_OPE = 'D' THEN
             V_QTE_VAL     := V_QTE_VAL - nvl(CUR_EVT.QTE_EVT,0);
             V_VAL_ACQ     := V_VAL_ACQ - (nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             IF V_QTE_VAL != 0 then
                 V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
             ELSE
                 V_VAL_ACQ := 0;
                 V_CMP_VAL := 0;
             END IF;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
             V_VAL_REA_VAL := V_VAL_REA_VAL + (CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - V_CMP_VAL));
          ELSE
             RETURN -1; -- Sense de l'opération non défini
          END IF;          
      END LOOP;
      /*message(to_char(V_QTE_VAL)||'*'||    
to_char(V_VAL_ACQ )||'*'||
to_char(V_DAT_DOP_VAL)||'*'||
CUR_PTR.CPT_COD_CPT  ||'*' ||        
to_char(CUR_PTR.VAL_COD_VAL)||'*');pause;*/
      IF nvl(V_QTE_VAL,0) !=0  THEN
          insert into portefeuille_retroactif(QTE_VAL,
                                      QTE_BLO_VAL    ,   
                                      VAL_REA_VAL    ,
                                      COU_ACQ_VAL    ,
                                      COM_VAL        ,
                                      DAT_DOP_VAL    ,  
                                       
                                      NUM_DOS        , 
                                           
                                      CPT_COD_CPT    , 
                                      VAL_COD_VAL    
                                       )  

      values(                         V_QTE_VAL              ,
                                      0   ,   
                                      V_VAL_REA_VAL          ,
                                      V_VAL_ACQ              ,
                                      V_CMP_VAL              ,
                                      V_DAT_DOP_VAL          ,  
                                       
                                      V_NUM_DOS              , 
                                       
                                      CUR_PTR.CPT_COD_CPT    , 
                                      CUR_PTR.VAL_COD_VAL  );   
  END IF;
   END LOOP; 
   RETURN V_NUM_DOS;     
END;
/

