create view TIT_V_WC_MVTS as
Select 
NUM_MVT , --                       NOT NULL NUMBER(20)
DAT_MVT , --                      NOT NULL DATE
LIB_OPE , --                      NOT NULL VARCHAR2(100)
COD_OPE , --                      NOT NULL VARCHAR2(30)
REF_OPE , --                               VARCHAR2(20)
COM_INT , --                      NOT NULL NUMBER(18,3)
MNT_RUS , --                      NOT NULL NUMBER(18,3)
TVA_RUS , --                      NOT NULL NUMBER(18,3)
MNT_CTB , --                      NOT NULL NUMBER(18,3)
TVA_CTB , --                      NOT NULL NUMBER(18,3)
TVA_INT , --                    NOT NULL NUMBER(18,3)
MNT_NET , --                      NOT NULL NUMBER(18,3)
COD_STA , --                      NOT NULL NUMBER(4,3)
COU_MVT , --                               NUMBER(18,3)
NUM_ORD , --                              NUMBER(12,3)
DAT_ORD , --                               DATE
NUM_TRA , --                               VARCHAR2(20)
COD_VAL , --                               NUMBER(30)
NUM_CPT , --                      NOT NULL VARCHAR2(20)
FAM_OPE , --                      NOT NULL NUMBER(3)
QTE_MVT , --                               NUMBER(12)
DAT_TRA   --                                DATE      
 from   wc_mvts@wc_afc
/

