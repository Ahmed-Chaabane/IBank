create view V_FSI_WC_ORDRE as
select
 ORIGINE ,
 SEN_ORD ,   NUM_ORD_BO,
 DAT_ORD_BO, NUM_ORD ,
 DAT_FIN ,   QTE_ORD  ,
 QTE_EXE,    QTE_DEV ,
 NUM_CPT,    COD_VAL,
 TYP_LIMITE, COURS,
 USE_CRE  ,  DAT_CRE,
 COD_STA   , NAT_INS_OP ,
 DAT_DEB , --
 EST_ORD , --
 COD_STA_BO   , --
  USE_MOD      , --
 DAT_MOD     , --
 QTE_EXE_JRN , --
 COD_STA_TRS , --
 ORD_INT    , --
 MOTIF      , --
 IDE_ORD    ,
 IDE_ORD_INI  ,
 NUM_ORD_INI  ,
 ORIGINE_MOD  ,
 REF_ORD      ,
 DAT_SAI_EN_BOU ,
 ATTENTE       ,
 OLD_EXE_JRN   ,
 ORD_WEB_INI   ,
 MNT_IMP       ,
 OLD_QTE_EXE
 from wc_ordre@ldb_fsi
/

