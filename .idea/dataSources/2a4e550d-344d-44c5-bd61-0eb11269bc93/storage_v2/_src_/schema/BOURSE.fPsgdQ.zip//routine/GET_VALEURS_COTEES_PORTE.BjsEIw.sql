create FUNCTION           "GET_VALEURS_COTEES_PORTE" (
 p_num_cpt in varchar
)
  return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
/*
fonction pour l'affichage des valeurs lors de la vente
*/
  OPEN liste FOR 
    select val.COD_VAL,  ltrim(MNE_VAL)
    from wc_valeur val, wc_portefeuille porte
    where porte.num_cpt= p_num_cpt and porte.cod_val = val.cod_val and porte.qte_val!=0 and
    val.ADM_COT ='O' and val.DAT_FIN_NEG is null
    order by ORD_AFF;
  return liste;
end;
/

