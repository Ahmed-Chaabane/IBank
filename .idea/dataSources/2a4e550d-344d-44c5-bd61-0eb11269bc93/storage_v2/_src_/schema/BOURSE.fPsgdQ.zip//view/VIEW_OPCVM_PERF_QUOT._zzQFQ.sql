create view VIEW_OPCVM_PERF_QUOT as
SELECT DISTINCT j.alias,
    j.DAT_IVL,
    j.vl_ivl,
    p.actif_net,
    v.dat_ivl,
    v.vl_ivl
  FROM sc_vl_ngtrend j  
  JOIN sc_vl_ngtrend v
  ON v.dat_ivl = j.dat_ivl_veille
  AND v.alias  = j.alias
  LEFT JOIN sc_prtf_ngtrend p
  ON p.alias     = j.alias
  AND p.dat_prtf = j.dat_ivl
  ORDER BY j.dat_ivl DESC
/

