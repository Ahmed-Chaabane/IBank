create FUNCTION          "F_TIT_CORRECTION_PRTF" (P_COD_CPT VARCHAR2,P_VAL_COD_VAL NUMBER) RETURN NUMBER IS

---    -1  Sens de l'opération non défini    autrement le n° du dossier
                                           
cursor PTR is select distinct val_cod_val,com_cod_cpt cpt_cod_cpt 
              from evenement
              where COM_COD_CPT = NVL(P_COD_CPT,COM_COD_CPT) 
                and VAL_COD_VAL = NVL(P_VAL_COD_VAL,VAL_COD_VAL) 
                  and sta_cod_sta!=2;
CURSOR EVT(V_COD_VAL NUMBER,V_CPT_COD_CPT VARCHAR2) IS SELECT com_cod_cpt,qte_evt,cou_evt,COM_BOU_EVT_1,TVA_BOU_MVT_1,OPE_COD_OPE,DAT_CPT_EVT,
                                    COM_BOU_EVT_2,TVA_BOU_MVT_2,COM_BOU_EVT_3,TVA_BOU_MVT_3,   COM_INT_EVT,TVA_COM_INT_EVT       /* + INDEX(EVENEMENT,EVT_PORT_RETRO_I) */
                                FROM EVENEMENT
                                WHERE COM_COD_CPT = V_CPT_COD_CPT AND
                                      VAL_COD_VAL = V_COD_VAL AND
                                      FAM_OPE = 1   AND --Opé Sur Titre
                                      
                                      STA_COD_STA != 2 --Annulé
                                ---ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'2',997,'12',995,'41',990,'45',980,'47',970,1) desc ;
                                ORDER BY DAT_CPT_EVT,val_cod_val,dat_tra_evt,decode(ope_cod_ope,'29',1000,'30',999,'3',998,'1',997,'12',995,'41',990,'45',980,'47',970,'16',600,1) desc ;


    v_num_dos  Number;
    V_SGN_OPE  VARCHAR(1);
    V_QTE_BLO  Number(20);
    V_QTE_VAL  Number(20);
    V_QTE_INI  Number(20);
    V_VAL_ACQ  Number(18,3);
V_VAL_REA_VAL  Number(18,3);
N_VAL_REA_VAL  Number(18,3);
V_DAT_DOP_VAL  DATE;
    V_CMP_VAL  Number(18,3);
    V_COM_VAL  Number(18,3);
v_COU_ACT_VAL  number(18,3);
    N_VAL_ACQ  Number(18,3);
    V_TOT_COM  Number(18,3);
    N_CMP_VAL  Number(18,3);
    S_QTE_VAL  Number(15);
    V_PAR_COM  Number;
BEGIN

  select prt_num_dos.nextval into v_num_dos from dual;

   /**Completer le portefeuille rétroactif à partir des evenements*****/
   FOR  CUR_PTR IN PTR LOOP
     
     delete portefeuille where  CPT_COD_CPT = CUR_PTR.CPT_COD_CPT 
                           and  VAL_COD_VAL = CUR_PTR.VAL_COD_VAL ;
      
      V_QTE_VAL := 0;
      V_VAL_ACQ := 0;
      V_VAL_REA_VAL := 0;
      V_DAT_DOP_VAL := Null;
      V_QTE_BLO  :=0;
      V_COM_VAL := 0;
      N_VAL_ACQ := 0;
      V_TOT_COM := 0;
      N_VAL_REA_VAL :=0;
      S_QTE_VAL :=0;
      V_PAR_COM :=0;
      FOR CUR_EVT IN EVT(CUR_PTR.VAL_COD_VAL,CUR_PTR.CPT_COD_CPT) LOOP
          begin
          SELECT nvl(SGN_OPE,' ') INTO V_SGN_OPE  FROM OPERATION
                 WHERE COD_OPE = CUR_EVT.OPE_COD_OPE;
           Exception when others then return -10;
          end;
               
          V_COM_VAL := nvl(CUR_EVT.COM_BOU_EVT_1,0)  + nvl(CUR_EVT.TVA_BOU_MVT_1,0)+ 
                                    nvl(CUR_EVT.COM_BOU_EVT_2,0)  + nvl(CUR_EVT.TVA_BOU_MVT_2,0)+ 
                                    nvl(CUR_EVT.COM_BOU_EVT_3,0)  + nvl(CUR_EVT.TVA_BOU_MVT_3,0)+ 
                                    nvl(CUR_EVT.COM_INT_EVT,0)    + nvl(CUR_EVT.TVA_COM_INT_EVT,0);      
                     
       IF V_SGN_OPE = 'C' THEN
       	  V_TOT_COM := NVL(V_TOT_COM,0) + V_COM_VAL;
           If CUR_EVT.OPE_COD_OPE IN('90','91','92','93','95','96') THEN -- Opérations de deblocage
              V_QTE_BLO := nvl(V_QTE_BLO,0) - CUR_EVT.QTE_EVT;
           Else
             V_QTE_VAL     := V_QTE_VAL + nvl(CUR_EVT.QTE_EVT,0);
             V_VAL_ACQ     := V_VAL_ACQ + (nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             N_VAL_ACQ     := N_VAL_ACQ + V_COM_VAL +(nvl(CUR_EVT.QTE_EVT,0) * nvl(CUR_EVT.COU_EVT,0)) ;
             IF V_QTE_VAL != 0 then
                V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
                N_CMP_VAL := N_VAL_ACQ / V_QTE_VAL;
             ELSE
                V_VAL_ACQ := 0; --dépôt derniere opé apres solde négatif
                V_TOT_COM := 0;
             END IF;
           end if;
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
          ELSIF V_SGN_OPE = 'D' THEN
           If CUR_EVT.OPE_COD_OPE IN('80','81','82','83','85','86') THEN -- Opérations de deblocage

              V_QTE_BLO := nvl(V_QTE_BLO,0) + CUR_EVT.QTE_EVT;
           Else          
             IF V_QTE_VAL != 0 then
                 V_CMP_VAL := V_VAL_ACQ / V_QTE_VAL;
                 V_VAL_ACQ     := greatest(V_VAL_ACQ - (nvl(CUR_EVT.QTE_EVT,0) * nvl(V_CMP_VAL,0)),0) ;
                 N_CMP_VAL := N_VAL_ACQ / V_QTE_VAL;
                 N_VAL_ACQ     := greatest(N_VAL_ACQ  - (nvl(CUR_EVT.QTE_EVT,0) * nvl(N_CMP_VAL,0)),0) ;
             ELSE
                V_VAL_ACQ := 0;
                N_VAL_ACQ := 0;
             END IF;
             S_QTE_VAL     := V_QTE_VAL ;
             V_QTE_VAL     := V_QTE_VAL - nvl(CUR_EVT.QTE_EVT,0);
                if cur_evt.ope_cod_ope in ('2','17') then
                   V_VAL_REA_VAL := V_VAL_REA_VAL + (CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - V_CMP_VAL));
                   N_VAL_REA_VAL := N_VAL_REA_VAL - V_COM_VAL + (CUR_EVT.QTE_EVT * (CUR_EVT.COU_EVT - N_CMP_VAL));
                end if;
             if cur_evt.ope_cod_ope in ('2','4','17') and S_QTE_VAL > 0 THEN   
                   V_PAR_COM :=  V_TOT_COM * CUR_EVT.QTE_EVT / S_QTE_VAL ;
                   V_TOT_COM := greatest(V_TOT_COM -  V_PAR_COM,0);
             end if;
             end if;           
             V_DAT_DOP_VAL := CUR_EVT.DAT_CPT_EVT;
          ELSE
             RETURN -1; -- Sense de l'opération non défini
          END IF;

        IF V_QTE_VAL = 0  and CUR_EVT.OPE_COD_OPE  in ('2','4','17')
            then
            V_COM_VAL  := 0;
            V_TOT_COM  := 0;
            V_VAL_ACQ  := 0;
         ELSIF V_QTE_VAL = 0 THEN
            V_VAL_ACQ := 0;
            N_VAL_ACQ := NVL(V_TOT_COM,0);
            V_TOT_COM := 0;
          END IF;  
                        --CG$FORM_ERRORS.PUSH('date ='||CUR_EVT.dat_cpt_evt||' Acqu='|| V_VAL_ACQ ||' Qte ='||V_QTE_VAL);
          ----update evenement set CMP_INI_EVT = V_CMP_VAL ,QTE_INI =V_QTE_INI where num_evt = CUR_EVT.num_evt;          
          
---     message(' date ='||to_char(cur_evt.dat_cpt_evt,'dd/mm/yyyy')|| ' Operation =' ||cur_evt.ope_cod_ope||' Cmp='||V_CMP_VAL);
---  message(' date ='||to_char(cur_evt.dat_cpt_evt,'dd/mm/yyyy')|| ' Operation =' ||cur_evt.ope_cod_ope||' Cmp='||V_CMP_VAL);

      END LOOP;
 
      IF V_DAT_DOP_VAL IS NOT NULL THEN
           select COU_ACT_VAL into v_COU_ACT_VAL
           from tit_valeur 
           where cod_val = CUR_PTR.VAL_COD_VAL ;
          insert into portefeuille(QTE_VAL,
                                      QTE_BLO_VAL    ,   
                                      VAL_REA_VAL    ,
                                      COU_ACQ_VAL    ,
                                      COM_VAL        ,
                                      DAT_DOP_VAL    ,  
                                      CPT_COD_CPT    , 
                                      VAL_COD_VAL    ,
                                      VAL_ACT_POR )  

      values(                         V_QTE_VAL              ,
                                      V_QTE_BLO    ,   
                                      N_VAL_REA_VAL          ,
                                      V_VAL_ACQ              ,
                                      0,                  --V_COM_VAL              ,
                                      V_DAT_DOP_VAL          ,  
                                      CUR_PTR.CPT_COD_CPT    , 
                                      CUR_PTR.VAL_COD_VAL    ,
                                      v_COU_ACT_VAL *V_QTE_VAL );   
    END IF;
    
   END LOOP; 
   RETURN V_NUM_DOS;     
exception
  when others then return -1;
END;
/

