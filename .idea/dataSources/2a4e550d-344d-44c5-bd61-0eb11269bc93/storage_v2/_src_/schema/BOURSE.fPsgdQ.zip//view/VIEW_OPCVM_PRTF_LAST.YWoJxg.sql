create view VIEW_OPCVM_PRTF_LAST as
select distinct
 p.num_seq,p.dat_prtf, P.cod_grp,P.cod_prd,P.num_lig,P.cod_val,P.qte_val,P.prx_uni,P.prx_rev,P.cours,P.pied_cou,P.lattente,
P.interet,P.val_bou,P.part_actif,p.alias,P.cod_isin,P.actif_net,P.vl,P.nbr_action,p.ide_opcvm,P.ide_val
from sc_prtf_ngtrend P
where dat_prtf = 
(select max(dat_prtf) from sc_prtf_ngtrend)
/

