create view VIEW_OPCVM_PRTF_BTA as
SELECT distinct p.num_seq,
    p.dat_prtf,
    P.cod_prd,
    P.cod_val,
    p.cod_isin,
    p.alias,
    p.actif_net
  FROM sc_prtf_ngtrend P
    JOIN
    (SELECT cod_isin,
    MIN(dat_prtf) dat_prtf
    FROM sc_prtf_ngtrend
    GROUP BY cod_isin,
    extract(MONTH FROM dat_prtf),
    extract(YEAR FROM dat_prtf)
    ) M
    ON M.cod_isin = P.cod_isin
    AND M.dat_prtf=P.dat_prtf
  WHERE num_seq =160
/

