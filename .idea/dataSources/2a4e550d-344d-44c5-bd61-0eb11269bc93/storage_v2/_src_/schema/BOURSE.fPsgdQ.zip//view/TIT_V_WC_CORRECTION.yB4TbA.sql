create view TIT_V_WC_CORRECTION as
select 


 
COD_INS ,
NUM_CPT ,
COD_VAL ,
NBR_ACH ,
NBR_VEN ,
COD_STA ,
NUM_OPE ,
DAT_JOU  

    From wc_correction@wc_afc

/

