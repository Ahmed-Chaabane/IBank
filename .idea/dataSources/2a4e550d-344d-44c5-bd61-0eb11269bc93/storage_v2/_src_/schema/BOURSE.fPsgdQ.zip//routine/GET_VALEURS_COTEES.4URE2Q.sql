create FUNCTION           "GET_VALEURS_COTEES" return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
  OPEN liste FOR 
    select COD_VAL, ltrim(MNE_VAL)
    from wc_valeur
    where web_negos='O'
    order by ltrim(MNE_VAL);
  return liste;
end;
/

