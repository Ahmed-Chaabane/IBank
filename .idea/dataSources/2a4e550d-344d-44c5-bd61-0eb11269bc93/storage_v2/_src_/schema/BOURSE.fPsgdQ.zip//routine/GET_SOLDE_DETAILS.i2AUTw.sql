create PROCEDURE           "GET_SOLDE_DETAILS" (
     p_num_cpt in number,
     p_PIN_CLI out varchar, 
     p_LIB_CPT out varchar, 
     p_SLD_ESP out number,
     p_SLD_SIC out number,
     p_SLD_ACH out number,
     p_CHQ_ENC out number,
     p_SLD_BLO out number,
     p_SLD_CMP out number,
 p_LIB_TYP_CPT out varchar,
     p_CON_SIC out varchar
)
as
begin            
      SELECT 
            cpt.PIN_CLI,
            cpt.LIB_CPT,
            NVL(SLD_ESP, 0),
            NVL(SLD_SIC, 0),
            NVL(SLD_ACH, 0),
            NVL(CHQ_ENC, 0),
            NVL(SLD_BLO, 0),
            NVL(SLD_CMP, 0),
            typ.LIB_CPT,
            nvl(CON_SIC,'N')
      INTO p_pin_cli, 
      p_LIB_CPT,
      p_SLD_ESP, 
      p_SLD_SIC, 
      p_SLD_ACH,
      p_CHQ_ENC,
      p_SLD_BLO,
      p_SLD_CMP,
      p_LIB_TYP_CPT,
      p_CON_SIC
            FROM WC_COMPTE cpt, WC_TYPE_COMPTE typ 
         WHERE cpt.num_cpt = p_num_cpt and typ.TYP_CPT = cpt.TYP_CPT;
  /*   SELECT
            PIN_CLI,
            NVL(SLD_ESP, 0) AS SLD_ESP,
            NVL(SLD_SIC, 0) AS SLD_SIC,
            NVL(SLD_ACH, 0) AS SLD_ACH,
            NVL(CHQ_ENC, 0) AS CHQ_ENC
    INTO p_pin_cli, p_SLD_ESP, p_SLD_SIC, p_SLD_ACH, p_CHQ_ENC 
            FROM WC_COMPTE
            WHERE num_cpt = p_num_cpt;*/            
end;
/

