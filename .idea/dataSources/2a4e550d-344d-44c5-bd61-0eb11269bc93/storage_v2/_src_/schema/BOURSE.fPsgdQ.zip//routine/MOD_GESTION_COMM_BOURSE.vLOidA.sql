create PROCEDURE          "MOD_GESTION_COMM_BOURSE" (w_cod_ope in varchar2,w_cod_cpt in varchar2,
          w_typ_tra in varchar2,w_num_evt in number,w_cod_val in NUMBER,
          w_mnt_opr in number,w_dat_tra in date,w_dat_jou in date,w_cod_tar in number,
          x_tot_mnt_com in out number,x_tot_mnt_tva in out number,w_flag in varchar2,
          x_err in out number,x_reponse in out VARCHAR2) IS

 
  
BEGIN


   begin
      ramene_detail_com_b(w_cod_ope,w_typ_tra,w_dat_tra,w_dat_jou,w_num_evt,w_cod_tar,
            w_mnt_opr,w_cod_cpt,w_cod_val,x_tot_mnt_com,x_tot_mnt_tva,w_flag,
            x_err,x_reponse);
            x_tot_mnt_com := round(nvl(x_tot_mnt_com,0),3);
            x_tot_mnt_tva := round(nvl(x_tot_mnt_tva,0),3);

    exception
             when no_data_found then         
             x_err:=1;
             x_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(w_cod_ope))||'-'||
                          ltrim(rtrim(w_cod_cpt))||'-'||ltrim(rtrim(to_char(w_cod_tar)))||
                          ' Inéxistante  !!!!';
                return;
             when too_many_rows then
             x_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(w_cod_ope))||'-'||
                          ltrim(rtrim(w_cod_cpt))||'-'||ltrim(rtrim(to_char(w_cod_tar)))||
                          ' Duppliqué !!!!';
               return;
                      
  end;

END;
/

