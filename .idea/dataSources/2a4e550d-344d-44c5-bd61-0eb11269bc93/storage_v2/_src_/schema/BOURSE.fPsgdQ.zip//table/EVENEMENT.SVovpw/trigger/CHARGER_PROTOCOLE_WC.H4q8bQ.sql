create trigger CHARGER_PROTOCOLE_WC
    before insert or update of NUM_EVT,LIB_EVT,REF_EVT,DAT_CPT_EVT,COM_BOU_EVT_1,COM_BOU_EVT_2,COM_BOU_EVT_3,COM_INT_EVT,COU_EVT,DAT_TRA_EVT,NUM_REF_EVT,QTE_EVT,TVA_BOU_MVT_1,TVA_BOU_MVT_2,TVA_BOU_MVT_3,TVA_COM_INT_EVT,COM_COD_CPT,VAL_COD_VAL,OPE_COD_OPE,STA_COD_STA,ORD_NUM_ORD,ORD_DAT_REC,MNT_NET,FAM_OPE
    on EVENEMENT
    for each row
BEGIN 
IF INSERTING THEN 
   insert into wc_protocole@WC_AFC (
   NUM_OPE,DAT_JOU,ORIGINE,MAT_CRE,DAT_CRE,COD_STA,
COD_INS,COD_CPT,COD_OPE,NOM_UTI,COD_STA_ENV,
NUM_LOT,COD_VAL,COU_REF,QTE_VAL,COM_BOU,TVA_BOU,
MNT_COM,MNT_TVA,LIB_EVT,cod_tar_bvmt,dat_ord,mot_pas,cod_tar_inter,
montant_1,fam_ope) values

(wc_seq_protocole.nextval@WC_AFC,:new.DAT_CPT_EVT,'B',:new.usr_mod,:new.DAT_tra_evt,'1',
'105',:new.com_cod_cpt,:new.ope_cod_ope,'I','1',
999,:new.val_cod_val,:new.cou_evt,:new.QTE_evt,
nvl(:new.COM_BOU_EVT_1,0) + nvl(:new.COM_BOU_EVT_2,0)
+ nvl(:new.COM_BOU_EVT_3,0) 
,nvl(:new.TVA_BOU_MVT_1,0) + nvl(:new.TVA_BOU_MVT_2,0)
+ nvl(:new.TVA_BOU_MVT_3,0), 

:new.COM_INT_EVT,:new.TVA_COM_INT_EVT,:new.LIB_EVT,:new.num_evt,
:new.ORD_DAT_REC,:new.ref_evt,:new.num_ref_evt,:new.mnt_net,:new.fam_ope);
   END IF;
IF UPDATING and :Old.sta_cod_sta!=2 THEN
   insert into wc_protocole@WC_AFC(
   NUM_OPE,DAT_JOU,ORIGINE,MAT_CRE,DAT_CRE,COD_STA, 
COD_INS,COD_CPT,COD_OPE,NOM_UTI,COD_STA_ENV,
NUM_LOT,COD_VAL,COU_REF,QTE_VAL,COM_BOU,TVA_BOU,
MNT_COM,MNT_TVA,LIB_EVT,cod_tar_bvmt,dat_ord,mot_pas,cod_tar_inter, 
montant_1,fam_ope) values 
 
(wc_seq_protocole.nextval@WC_AFC,:new.DAT_CPT_EVT,'B',:new.usr_mod,:new.DAT_tra_evt,'1',
'105',:new.com_cod_cpt,:new.ope_cod_ope,'M',:new.sta_cod_sta,
1000,:new.val_cod_val,:new.cou_evt,:new.QTE_evt,
nvl(:new.COM_BOU_EVT_1,0) + nvl(:new.COM_BOU_EVT_2,0)
+ nvl(:new.COM_BOU_EVT_3,0) 
,nvl(:new.TVA_BOU_MVT_1,0) + nvl(:new.TVA_BOU_MVT_2,0)
+ nvl(:new.TVA_BOU_MVT_3,0), 

:new.COM_INT_EVT,:new.TVA_COM_INT_EVT,:new.LIB_EVT,:new.NUM_EVT,
:new.ORD_DAT_REC,:new.ref_evt,:new.num_ref_evt,:new.mnt_net,:new.fam_ope);
END IF;
END;
/

