create FUNCTION           "GETCOMPTE" (
 p_nom_uti in varchar
)
RETURN TYPES.ref_cursor
as
liste types.ref_cursor;
begin
   OPEN liste FOR 
            select cpt.num_cpt, cpt.LIB_CPT
            from wc_compte cpt , wc_det_acces acc
            where acc.nom_uti= p_nom_uti and cpt.num_cpt = acc.num_cpt
            and nvl(AUT_ACH,'O')='O' and nvl(aut_ven,'O')='O'
            order by lpad(num_cpt,20,'0');
    RETURN liste;
end;
/

