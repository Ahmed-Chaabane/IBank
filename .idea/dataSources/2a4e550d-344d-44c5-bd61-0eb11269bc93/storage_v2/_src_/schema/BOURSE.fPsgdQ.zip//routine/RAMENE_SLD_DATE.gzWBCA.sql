create PROCEDURE          "RAMENE_SLD_DATE" (P_cod_cpt in varchar2,P_date in date, P_solde out number )  IS

w_solde number:=0;
tot_mvt number(18,3):=0;
w_Cod_int  number;
w_dat_jou  Date ;
begin
  select dat_jou into w_dat_jou from journee;
       

 
     Begin
     select sol_esp_cpt into w_solde 
           from  compte 
           where cod_cpt=P_cod_cpt;
     select nvl(sum(mnt_net),0) into tot_mvt 
            from evenement
            where dat_cpt_evt > P_date 
            and com_cod_cpt = P_cod_cpt
            and sta_cod_sta!=2;

     End;
 

     p_solde := nvl(w_solde,0) - nvl(tot_mvt,0);

end;
/

