create PROCEDURE         RAMENE_TAU_TVA (w_cod_tva in  varchar2,w_dat_tra in date,w_cod_cpt in varchar2,
          x_tau_tva out number,
          x_err out number,x_reponse out char) IS

    z_exo_tva   varchar2(1);
    z_dat_deb_tva   date;
    z_dat_fin_tva   date;


BEGIN
 x_tau_tva := 0;
 select exo_tva, nvl(dat_deb_tva,SYSDATE) , NVL(dat_fin_tva,SYSDATE) into
        z_exo_tva, z_dat_deb_tva, z_dat_fin_tva from compte
        where cod_cpt=w_cod_cpt;
  if z_exo_tva='O' and w_dat_tra between z_dat_deb_tva and z_dat_fin_tva
     then
     x_tau_tva := 0;
 else
     begin       
         select val_tva/100 into x_tau_tva
         from tva 
         where cod_tva=w_cod_tva
         and trunc(w_dat_tra) between trunc(dat_deb_vld_tva) and trunc(dat_fin_vld_tva);
     Exception
       When no_data_found then
       x_err :=1;
       x_reponse :='Taux TVA inexstant pour la Journée de ='||
              to_char(w_dat_tra,'dd/mm/yyyy')||' Code TVA='||w_cod_tva;
       When too_many_rows then
       x_err :=1;
       x_reponse :='Taux TVA Chevauche Entre 2 Periode  pour la Journée de ='||
              to_char(w_dat_tra,'dd/mm/yyyy')||' Code TVA='||w_cod_tva;
     end;
  end if;
 Exception
       When no_data_found then
       x_err :=1;
       x_reponse :='Compte inexstant N° ='||w_cod_cpt;
       When too_many_rows then
       x_err :=1;
       x_reponse :='Compte Duppliqué  N° ='||w_cod_cpt;

END;
/

