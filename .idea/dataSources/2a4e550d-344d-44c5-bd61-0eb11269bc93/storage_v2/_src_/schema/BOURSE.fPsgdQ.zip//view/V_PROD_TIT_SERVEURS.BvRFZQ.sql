create view V_PROD_TIT_SERVEURS as
select
 COD_SRV ,
 LIB_SRV ,
 ETA_CON ,
 IP_SRV  ,
 NUM_SEQ from tit_serveurs@ldb_prod
/

