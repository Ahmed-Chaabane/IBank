create view V_PROD_TIT_COURS_JOUR as
select dat_jou,cod_val,cou_ref,ind_res,cou_clo from TIT_COURS_JOUR@ldb_prod
/

