create FUNCTION  F_TIT_JOUR_SUIVANT (P_dat_jou in date,P_Nbr_jou in number)  RETURN DATE IS

jour date:= P_dat_jou;
V_nbr_jou  Number(6) := nvl(P_nbr_jou,1);
BEGIN
 
 while V_nbr_jou >=1
  Loop
    IF EST_FERIE(JOUR + 1)= FALSE then
       V_nbr_jou := V_nbr_jou - 1;
    END IF;
       jour := JOUR + 1;
  End loop;
 RETURN (JOUR  );
END;
/

