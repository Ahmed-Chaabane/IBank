create PROCEDURE           "UPDATE_STATUT" (
   p_num_ordre in number,
     p_cod_sta out varchar,
 p_cod_sta_trs out varchar,
     p_nat_ins out number,
     p_dat_fin out varchar
)
as

begin
    select cod_sta, cod_sta_trs, nat_ins_op, dat_fin
    into p_cod_sta, p_cod_sta_trs,p_nat_ins, p_dat_fin
    from wc_ordre
    where num_ord = p_num_ordre;
end;
/

