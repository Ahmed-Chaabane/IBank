create view TIT_V_ORDRE as
SELECT NUM_ORD ,DAT_REC ,            DAT_DEB ,
    DAT_FIN  ,
EST_ORD,             NAT_INS_ORD ,    NUM_ORD_MOD ,QTE_EXE  ,
QTE_ORD ,   REF_ORD ,   TYP_REC  ,   DAT_SAI_EN_BOU ,
DAT_MOD  ,         USR_MOD  ,         VAL_COD_VAL,    CPT_COD_CPT,
STA_COD_STA ,  TYP_ORD_COD_TYP_ORD ,     TYP_VALORD_COD_TYP_VAL,
COU_LIM ,            DAT_CAR_ORD , FLG_GLO_ORD  , AVS_PAY_ORD  ,
SEN_ORD  ,    FLG_ORD  ,     ORD_INT  ,      COD_CLI_SIG ,COD_TAR  ,
COM_ORD ,  TYP_COMPTE,
IDE_ORD,       STA_FIX  ,   IDE_INI_ORD ,QTE_DEV ,origine ,nom_uti,qte_res_jrn,
usr_for,sld_trv,origine_mod,OLD_EXE_JRN,QTE_EXE_JRN,seq_app,cod_age_ope,cod_age_cpt,
ref_ext ,old_qte_exe ,usr_cre,dat_cre
  from ordre
Union
SELECT NUM_ORD ,DAT_REC ,            DAT_DEB ,            DAT_FIN  ,
EST_ORD,             NAT_INS_ORD ,    NUM_ORD_MOD ,QTE_EXE  ,
QTE_ORD ,   REF_ORD ,   TYP_REC  ,   DAT_SAI_EN_BOU ,
DAT_MOD  ,         USR_MOD  ,         VAL_COD_VAL,    CPT_COD_CPT,
STA_COD_STA ,  TYP_ORD_COD_TYP_ORD ,     TYP_VALORD_COD_TYP_VAL,
COU_LIM ,            DAT_CAR_ORD , FLG_GLO_ORD  , AVS_PAY_ORD  ,
SEN_ORD  ,    FLG_ORD  ,     ORD_INT  ,      COD_CLI_SIG ,COD_TAR  ,
COM_ORD ,  TYP_COMPTE ,IDE_ORD,       STA_FIX  ,       IDE_INI_ORD ,QTE_DEV,
origine ,nom_uti,qte_res_jrn,usr_for,sld_trv,origine_mod,OLD_EXE_JRN,QTE_EXE_JRN,seq_app,cod_age_ope,cod_age_cpt,
ref_ext ,old_qte_exe ,usr_cre,dat_cre
 from TIT_HISTO_ORDRE
/

