create FUNCTION          "F_TIT_CAL_MVT_ESP" (P_SENS IN VARCHAR2,P_COD_CPT IN VARCHAR2
 ) Return Number Is

V_TOT_MVT_ESP Number(18,3);

BEGIN
   IF P_SENS ='E' THEN 
       select nvl(abs(sum(mnt_net)),0) into V_TOT_MVT_ESP from evenement where
             ---trunc(dat_cpt_evt) between P_dat_deb  and P_dat_fin
               com_cod_cpt=P_COD_CPT  and ope_cod_ope in ('201','5','28','203')
             and sta_cod_sta!=2;

   ELSE
          --- decaissement
          select round(nvl(abs(sum(mnt_net)),0),0) into V_TOT_MVT_ESP from evenement where
            --- trunc(dat_cpt_evt) between v_dat_deb  and v_dat_fin
               com_cod_cpt=P_COD_CPT  and ope_cod_ope in ('200', '7' ,'6', '202')
             and sta_cod_sta!=2;
   END IF;
   return nvl(V_TOT_MVT_ESP,0);
END;
/

