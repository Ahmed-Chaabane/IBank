create view VIEW_OPCVM_PRTF_VAL_MONTH as
SELECT distinct P.DAT_PRTF,
    extract(MONTH FROM p.dat_prtf) AS MONTH,
    extract(YEAR FROM p.dat_prtf)  AS YEAR,
    P.VAL_BOU,
    P."ALIAS",
    P.COD_VAL,
    P.NUM_SEQ,
    P.COD_ISIN
  FROM 
  (SELECT MAX(dat_prtf) as dat_prtf,
      ALIAS
    FROM sc_prtf_ngtrend
    GROUP BY ALIAS,
      extract(MONTH FROM dat_prtf),
      extract(YEAR FROM dat_prtf)
    ) m
  join sc_prtf_ngtrend P on p.alias = m.alias and p.dat_prtf = m.dat_prtf
/

