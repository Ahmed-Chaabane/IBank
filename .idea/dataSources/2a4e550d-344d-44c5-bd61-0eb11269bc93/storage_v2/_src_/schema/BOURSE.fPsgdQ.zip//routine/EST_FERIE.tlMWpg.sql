create FUNCTION EST_FERIE (V_JOUR IN DATE) RETURN BOOLEAN IS

CURSOR feries IS
  SELECT  DAT_JOU_FER, REL_JOU_FER
  FROM jour_ferie;
  --WHERE STA_JOU_FER = 1;           --valide 
  
j_fer feries%ROWTYPE;
num_jour NUMBER(2);

BEGIN
 
/*tester si c'est un weekend*/
SELECT TO_CHAR(V_JOUR,'d') INTO num_jour FROM DUAL;

IF num_jour = 6 OR num_jour = 7   
             --samedi ou dimanche
THEN 
 -- V_MES := 'Le jour est ferié';
  RETURN (TRUE);
END IF;

/*tester si c'est un jour ferié*/
OPEN feries;
LOOP
 FETCH feries INTO j_fer;
 EXIT WHEN feries%NOTFOUND;
IF j_fer.REL_JOU_FER = 1 
      --ce n'est pas civile alors l'année est importante
THEN

   IF j_fer.DAT_JOU_FER = V_JOUR 
   THEN
       --V_MES := 'Le jour est ferié';
       RETURN (TRUE);
   END IF;  

ELSIF j_fer.REL_JOU_FER IS NULL 
      --jour civile alors l'année n'est pas importante
  THEN
    IF TO_CHAR(j_fer.DAT_JOU_FER,'DD/MM') = TO_CHAR(V_JOUR,'DD/MM')
    THEN 
         --V_MES := 'Le jour est ferié';
         RETURN (TRUE);
    END IF; 
END IF;
END LOOP;
CLOSE feries;  

--V_MES := 'Le jour n''est pas ferié';
RETURN (FALSE);

END;
/

