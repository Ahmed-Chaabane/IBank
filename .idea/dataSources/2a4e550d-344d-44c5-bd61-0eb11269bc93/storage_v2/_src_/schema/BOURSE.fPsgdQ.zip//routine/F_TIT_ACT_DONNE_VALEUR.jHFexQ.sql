create FUNCTION  F_TIT_ACT_DONNE_VALEUR  (                          p_num_seq in number,
                             P_Cod_mmtp In Varchar2,
                             P_Cod_isin In Varchar2,
                             P_dern_cou In number,
                             P_seuil_h in number,
                             P_seuil_b In Number,
                             P_lim_ach in Number,
                             P_lim_ven In Number,
                             P_statut In varchar2) Return integer Is  

Begin
	begin
	if P_Cod_mmtp in ('1','2','32') then  --dern
	   update tit_donne_valeur set dern_cou = P_dern_cou, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
	     begin
	       insert into tit_donne_valeur(num_seq,cod_isin, dern_cou) values(p_num_seq,P_Cod_isin,P_dern_cou );
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;
	   end if;	   
	elsif P_Cod_mmtp = '41' then --meilleurs ach
	   update tit_donne_valeur set  lim_ach = P_lim_ach, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
       begin	   
	     insert into tit_donne_valeur(num_seq,cod_isin, lim_ach ) values(p_num_seq,P_Cod_isin,P_lim_ach);
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;	     
	   end if;	  	   
	elsif P_Cod_mmtp = '42' then --meilleurs ven
	   update tit_donne_valeur set  lim_ven = P_lim_ven, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
       begin	   
	     insert into tit_donne_valeur(num_seq,cod_isin,lim_ven ) values(p_num_seq,P_Cod_isin,P_lim_ven);
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;	     
	   end if;		   
	elsif P_Cod_mmtp = '5' then -- statut
	   update tit_donne_valeur set  statut = P_statut, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
       begin	   
	     insert into tit_donne_valeur(num_seq,cod_isin, statut ) values(p_num_seq,P_Cod_isin,P_statut);
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;	     
	   end if;			   
	elsif P_Cod_mmtp = '371' then -- seuils haut
	   update tit_donne_valeur set  seuil_haut = P_seuil_h, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
       begin	   
	     insert into tit_donne_valeur(num_seq,cod_isin, seuil_haut) values(p_num_seq,P_Cod_isin,P_seuil_h);
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;	     
	   end if;		
	elsif P_Cod_mmtp = '372' then -- seuils bas
	   update tit_donne_valeur set  seuil_bas = P_seuil_b, num_seq =  p_num_seq where cod_isin = P_Cod_isin and num_seq <= p_num_seq;
	   if(SQL%NOTFOUND) then
       begin	   
	     insert into tit_donne_valeur(num_seq,cod_isin,seuil_bas) values(p_num_seq,P_Cod_isin,P_seuil_b);
	     exception
	       when DUP_VAL_ON_INDEX then
	         return 0;
	     end;	     
	   end if;	   
	else
	 return -1;
	end if;
	exception	 when others then
	    return to_number('-' || P_Cod_mmtp);
	end;

 Return 10;
END;
/

