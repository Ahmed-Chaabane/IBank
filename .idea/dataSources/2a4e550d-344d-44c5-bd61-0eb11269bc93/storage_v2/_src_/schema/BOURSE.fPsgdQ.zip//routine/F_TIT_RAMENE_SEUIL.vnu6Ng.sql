create FUNCTION  F_TIT_RAMENE_SEUIL (P_Cod_isin in Varchar2,
                             P_der_cou       Out Number,
                             P_Seuil_Haut   Out Number, 
                             P_Seuil_bas     Out Number, 
                             P_lim_achat     Out Number, 
                             P_lim_vente     Out Number, 
                             P_statut        Out varchar2) Return number Is  
  V_dern_cou  Number(18,3);
V_seuil_haut  Number(18,3);
 V_seuil_bas  Number(18,3);
   V_lim_ach  Number(18,3);
   V_lim_ven  Number(18,3);
    V_STATUT  Varchar2(5);
Begin
	/*begin
   Select dern_cou,SEUIL_HAUT,SEUIL_BAS,LIM_ACH,LIM_VEN,STATUT
          Into P_der_cou,P_seuil_haut,P_seuil_bas,P_lim_achat,P_lim_vente,P_STATUT From Tit_Donne_valeur
           Where cod_isin = P_cod_isin;
   exception
       when others then return 0;
   end;	  */
   
  begin
   Select dern_cou,SEUIL_HAUT,SEUIL_BAS,LIM_ACH,LIM_VEN,STATUT
          Into P_der_cou,P_seuil_haut,P_seuil_bas,P_lim_achat,P_lim_vente,P_STATUT From Tit_Donne_valeur@mdg_bvmt
           Where cod_isin = P_cod_isin;
   exception
       when others then return 0;
   end;	 
   
   return 0;
END;
/

