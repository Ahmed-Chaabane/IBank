create PACKAGE BODY "NGTREND_WEB" AS
  
 
  FUNCTION FN_VL RETURN WEB_VL_SET pipelined IS
    VL WEB_VL;
    DATE_PUB DATE;
  BEGIN
    select max(DAT_IVL) into DATE_PUB from SC_VL_NGTREND;
    for r in (select v1.ALIAS as OPCVM, v1.DAT_IVL, v1.VL_IVL, v1.DAT_IVL_VEILLE,v2.VL_IVL as VL_VEILLE 
      from sc_vl_ngtrend v1 join sc_vl_ngtrend v2 on v2.dat_ivl=v1.dat_ivl_veille and v2.alias = v1.alias 
      where v1.DAT_IVL = DATE_PUB)
        loop
          VL.OPCVM := r.OPCVM;
          VL.DATE_VL := r.DAT_IVL;
          VL.VL := r.VL_IVL;
          VL.DATE_VL_AVANT := r.DAT_IVL_VEILLE;
          VL.VL_AVANT := r.VL_VEILLE;
          pipe row(VL);
        end loop;
    return;
  end FN_VL;
  
  FUNCTION FN_ACTIF RETURN WEB_ACTIF_SET pipelined IS
    ACT WEB_ACTIF;
    DATE_PUB DATE;
  BEGIN
    select add_months(last_day(max(DAT_IVL))+1,-1) into DATE_PUB from SC_VL_NGTREND;
    for r in (
      select v.ALIAS as OPCVM,DATE_PUB DATE_ACTIF,P.ACTIF_NET, BT.ACT/P.ACTIF_NET*100 BT, ACT.ACT/P.ACTIF_NET*100 ACT,EMP.ACT/P.ACTIF_NET*100 EMP,
        OPCV.ACT/P.ACTIF_NET*100 OPCV,PLAC.ACT/P.ACTIF_NET*100 PLAC
      from SC_VL_NGTREND v
      join (select distinct alias,actif_net from sc_prtf_ngtrend where dat_prtf=DATE_PUB) P on P.alias=V.ALIAS
      left join
        (select ALIAS, sum(VAL_BOU) ACT from SC_PRTF_NGTREND 
          where DAT_PRTF=DATE_PUB and NUM_SEQ=160
          group by ALIAS) BT on BT.alias=V.alias
      left join
        (select ALIAS, sum(VAL_BOU) ACT from SC_PRTF_NGTREND 
          where DAT_PRTF=DATE_PUB and NUM_SEQ=11
          group by ALIAS) ACT on ACT.alias=V.alias
      left join
        (select ALIAS, sum(VAL_BOU) ACT from SC_PRTF_NGTREND 
          where DAT_PRTF=DATE_PUB and NUM_SEQ=165
          group by ALIAS) EMP on EMP.alias=V.alias
      left join
        (select ALIAS, sum(VAL_BOU) ACT from SC_PRTF_NGTREND 
          where DAT_PRTF=DATE_PUB and NUM_SEQ=14
          group by ALIAS) OPCV on OPCV.alias=V.alias
      left join
        (select ALIAS, sum(VAL_BOU) ACT from SC_PRTF_NGTREND 
          where DAT_PRTF=DATE_PUB and NUM_SEQ not in (14,160,11,165,170 /* Fonds Communs de Créances*/)
          group by ALIAS) PLAC on PLAC.alias=V.alias
      where dat_ivl=DATE_PUB)
        loop
          ACT.OPCVM := r.OPCVM;
          ACT.DATE_ACTIF := r.DATE_ACTIF;
          ACT.ACTIF_NET := r.ACTIF_NET;
          ACT.BT := r.BT;
          ACT.ACT := r.ACT;
          ACT.EMP := r.EMP;
          ACT.OPCV := r.OPCV;
          ACT.PLAC := r.PLAC;
          pipe row(ACT);
        end loop;
    return;
  end FN_ACTIF;

END NGTREND_WEB;
/

