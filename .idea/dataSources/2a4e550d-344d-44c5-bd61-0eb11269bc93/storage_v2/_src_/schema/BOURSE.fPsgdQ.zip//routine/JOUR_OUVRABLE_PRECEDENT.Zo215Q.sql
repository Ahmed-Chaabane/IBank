create FUNCTION JOUR_OUVRABLE_PRECEDENT (P_dat_jour IN DATE,P_NBR IN NUMBER) RETURN DATE IS

   V_jour date:= P_dat_jour;
V_nbr_jou Number := P_NBR;

BEGIN
 

  while V_nbr_jou != 0
   Loop
     IF EST_FERIE(V_jour -1)= FALSE then 
        V_nbr_jou := V_nbr_jou - 1;
      END IF;
      V_jour := V_jour -1 ;
   End loop;
 RETURN (V_jour);
END;
/

