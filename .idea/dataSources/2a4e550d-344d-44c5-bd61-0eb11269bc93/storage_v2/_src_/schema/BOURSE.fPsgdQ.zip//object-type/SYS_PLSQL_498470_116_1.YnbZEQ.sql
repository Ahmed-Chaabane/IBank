create TYPE "SYS_PLSQL_498470_116_1"                                                                                                                                                             as table of PARTAGE."SYS_PLSQL_498470_53_1";
/

