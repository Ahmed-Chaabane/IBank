create PROCEDURE           "RAMENE_DETAILS_VALEUR" (p_cod_val in number,
    p_der_cou out number,
    p_seuil_h out number,
    p_seuil_b out number) is
    
v_cod_isin varchar(20) := ramene_cod_isin(p_COD_VAL);
Begin
begin
    if(v_cod_isin = ' ') then
      null;
    end if;
    
    select dern_cou,seuil_haut, seuil_bas into p_der_cou,p_seuil_h,p_seuil_b
    from wc_donne_marche 
    where COD_ISIN = v_cod_isin;
    
  EXCEPTION 
  when no_data_found then 
     null;
  when others then
    null;
  end;
end;
/

