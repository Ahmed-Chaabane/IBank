create FUNCTION           "RAMENE_STOCK_TITRE" (
 p_num_cpt in varchar,
 p_cod_val in number,
 p_qte_val out number,
 p_qte_blo out number
)
return int
as

begin
 
/*begin
  select nvl(DER_COU,0) into p_der_cou from wc_valeur where cod_val = p_cod_val;
exception
when others then 
 p_der_cou :=0;
end;*/
------------------------------- 
begin
  select nvl(QTE_VAL,0),nvl( QTE_BLO_VAL,0) into p_qte_val, p_qte_blo
  from wc_portefeuille 
  where NUM_CPT = p_num_cpt and COD_VAL = p_cod_val;
  return 0;
exception
  when others then 
     p_qte_val :=0;
     p_qte_blo :=0;
     return -1;
end;

end;
/

