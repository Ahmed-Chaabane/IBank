create PROCEDURE           "VERIF_ACCES" (              
                P_uti_web in varchar2,
                P_num_cpt in varchar2,
                P_cod_ope in integer,
                P_cod_err out int,
                P_msg_err out varchar2
 ) IS
    
-- declarations
      v_aut char;
      v_sta varchar2(5);
  v_dat_fin date; 
      v_cnt int;  
 begin
--traitements generales
select count(1) into v_cnt  from wc_det_acces where nom_uti = P_uti_web;
if nvl(v_cnt,0) = 0 then
    P_cod_err := 12;
    P_msg_err := 'Vous n''avez pas de compte';
    return;
end if;
select COD_STA, DAT_FIN into v_sta,v_dat_fin  from wc_det_acces where nom_uti = P_uti_web and num_cpt=P_num_cpt;
  if(v_sta != '1') then
    P_cod_err := -1;
    select lib_long into P_msg_err from wc_statut where cod_sta = v_sta;
    return;
  elsif (v_dat_fin < sysdate) then
    P_cod_err := -2;
    P_msg_err := get_messages(P_cod_err);
    return;
  end if;
--traitements spécifiques
if P_cod_ope = 1 then -- achats
  SELECT nvl(AUT_ACH,'N') into v_aut FROM WC_PARAM_LOGICIEL;
  if(v_aut = 'O') then
    SELECT nvl(AUT_ACH,'N') into v_aut FROM WC_UTILISATEURS WHERE NOM_UTI= P_uti_web;
    if(v_aut = 'O') then
      select nvl(AUT_ACH,'N') into v_aut from wc_det_acces where nom_uti = P_uti_web and num_cpt = P_num_cpt;
      if(v_aut = 'O') then
        P_cod_err := 0;
        return;
      else
        P_cod_err := 11;
      end if;
    else
      P_cod_err := 12;
    end if;
  else
    P_cod_err := 13;
  end if;
  P_msg_err := get_messages(P_cod_err);
  return;  
  
elsif P_cod_ope = 2 then -- ventes
  SELECT nvl(AUT_VEN,'N') into v_aut FROM WC_PARAM_LOGICIEL;
  if(v_aut = 'O') then
    SELECT nvl(AUT_VEN,'N') into v_aut FROM WC_UTILISATEURS WHERE NOM_UTI= P_uti_web;
    if(v_aut = 'O') then
      select nvl(AUT_VEN,'N') into v_aut from wc_det_acces where nom_uti = P_uti_web and num_cpt = P_num_cpt;
      if(v_aut = 'O') then
        P_cod_err := 0;
        return;
      else
        P_cod_err := 21;
      end if;
    else
      P_cod_err := 22;
    end if;
  else
    P_cod_err := 23;
  end if;
  P_msg_err := get_messages(P_cod_err);
  return;  
end if;

 
 
end;
/

