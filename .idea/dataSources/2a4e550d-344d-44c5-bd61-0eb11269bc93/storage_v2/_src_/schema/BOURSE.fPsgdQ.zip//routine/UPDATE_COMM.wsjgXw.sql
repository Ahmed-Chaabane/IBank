create PROCEDURE           "UPDATE_COMM" (B_TOT in NUMBER,
   P_Cod_cpt in varchar2,P_Cod_val in number) IS
BEGIN

update wc_portefeuille set com_sim_ven = B_TOT where NUM_CPT =P_Cod_cpt and COD_VAL =P_Cod_val;
END;
/

