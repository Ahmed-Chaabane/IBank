create PROCEDURE   Ges_comm_inter_tranche(P_cod_tar in number ,
                                    P_mnt_ope in number,
                                    P_mnt_com out number,
                                    P_err out number,
                                    P_reponse out varchar2) IS
    
        L_mnt_opr   Number:=P_mnt_ope ;
    L_tau_tranche   Number;
        L_bor_min   Number(18,3);
        L_bor_max   Number(18,3);
        L_tranche   Number(18,3);
          L_recup   Number:=0;
BEGIN

  Loop
     Exit when L_mnt_opr = 0 ;
   Begin

     select nvl(tau_tar_sta,0)/1000,bor_min,bor_max into L_tau_tranche,L_bor_min,L_bor_max
            from detail_tarif_standard
            where cod_tar=P_cod_tar 
            and L_mnt_opr between bor_min and bor_max;

     if L_bor_min = 0
        then
        L_tranche := L_bor_max + L_recup;
        L_mnt_opr := L_Bor_min ;
     else  
        L_tranche := (L_mnt_opr - L_bor_min) + L_Recup;
        L_recup := 1/1000;
        L_mnt_opr := L_Bor_min - L_recup;
     End if;
     P_mnt_com := round(nvl(P_mnt_com,0),3) +  round((L_tranche*L_tau_tranche),3);


  exception
    when no_data_found then
    P_err :=1;
    P_reponse :='Attention (Detail Tarif Inter)='||ltrim(rtrim(P_cod_tar))||
                          ' Inéxistant !!!!';
    return;
    when too_many_rows then
     
    P_err :=1;
    P_reponse :='Attention (Detail Tarif Inter)='||ltrim(rtrim(P_cod_tar))||
                          ' Chevauche avec 2 Bornes!!!!';
    return;
   End;
   End loop;
END;
/

