create FUNCTION  F_TIT_VERIF_SEUIL (P_Cod_isin in Varchar2,
                             P_cours In number) Return number Is  
  V_dern_cou  Number(18,3);
V_seuil_haut  Number(18,3);
 V_seuil_bas  Number(18,3);
   V_lim_ach  Number(18,3);
   V_lim_ven  Number(18,3);
    V_STATUT  Varchar2(5);
Begin
	begin
   Select dern_cou,SEUIL_HAUT,SEUIL_BAS,LIM_ACH,LIM_VEN,STATUT
          Into V_dern_cou,V_seuil_haut,V_seuil_bas,V_lim_ach,V_lim_ven,V_STATUT From Tit_Donne_valeur
           Where cod_isin = P_cod_isin;
   exception
       when others then return 0;
   end;	     
   If P_cours between V_seuil_bas and V_seuil_haut then --- Cours respecte les seuils
   	  Return 0;
   ElsIf P_cours > V_seuil_haut then --- possibilte de gele la valeur a la haisse
   	  Return 1 ;
   Elsif P_cours < V_seuil_bas then --- possibilte de gele la valeur a la baisee
   		Return 2;
   Else
   	  Return 0 ;
   End If;		
END;
/

