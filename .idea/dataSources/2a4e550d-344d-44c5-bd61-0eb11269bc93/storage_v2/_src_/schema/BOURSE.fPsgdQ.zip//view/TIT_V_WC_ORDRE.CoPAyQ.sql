create view TIT_V_WC_ORDRE as
select 
ORIGINE ,--                        NOT NULL CHAR(1)
SEN_ORD ,--                       NOT NULL NUMBER(1)
NUM_ORD_BO ,--                             NUMBER(12)
DAT_ORD_BO ,--                             DATE
NUM_ORD    ,--                    NOT NULL NUMBER(12)
DAT_FIN    ,--                    NOT NULL DATE
QTE_ORD    ,--                    NOT NULL NUMBER(12)
QTE_EXE    ,--                    NOT NULL NUMBER(12)
QTE_DEV    ,--                             NUMBER(12)
NUM_CPT    ,--                    NOT NULL VARCHAR2(20)
COD_VAL    ,--                    NOT NULL NUMBER(30)
TYP_LIMITE ,--                    NOT NULL VARCHAR2(5)
COURS      ,--                             NUMBER(15,3)
USE_CRE    ,--                             VARCHAR2(30)
DAT_CRE    ,--                             DATE
COD_STA    ,--                    NOT NULL VARCHAR2(5)
NAT_INS_OP ,--                    NOT NULL NUMBER(1)
DAT_DEB    ,--                    NOT NULL DATE
EST_ORD    ,--                             NUMBER(18,3)
COD_STA_BO ,--                             VARCHAR2(5)
USE_MOD    ,--                             VARCHAR2(30)
DAT_MOD    ,--                             DATE
QTE_EXE_JRN ,--                            NUMBER(12)
COD_STA_TRS ,--                            VARCHAR2(5)
ORD_INT     ,--                            NUMBER(1)
SLD_ESP     ,--                            NUMBER(18,3)
SLD_SIC     ,--                            NUMBER(18,3)
SLD_ACH     ,--                            NUMBER(18,3)
CHQ_ENC     ,--                            NUMBER(18,3)
SLD_BLO     ,--                            NUMBER(18,3)
SLD_CMP     ,--                            NUMBER(18,3)
CON_SIC     ,--                            VARCHAR2(1)
MOTIF       ,--                            VARCHAR2(5)
IDE_ORD     ,--                            NUMBER(12)
IDE_ORD_INI ,--                            NUMBER(12)
NUM_ORD_INI ,--                            NUMBER(12)
ORIGINE_MOD ,--                            VARCHAR2(1)
REF_ORD     ,--                            NUMBER(12)
DAT_SAI_EN_BOU ,--                         DATE
OLD_EXE_JRN    ,--                         NUMBER(12)
ORD_WEB_INI    ,--                         NUMBER(12)
MNT_IMP         --                         NUMBER(18,3)         
 from   wc_ordre@wc_afc
/

