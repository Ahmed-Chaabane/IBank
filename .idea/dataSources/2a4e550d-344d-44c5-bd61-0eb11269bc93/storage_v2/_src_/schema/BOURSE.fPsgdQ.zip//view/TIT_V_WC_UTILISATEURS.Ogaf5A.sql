create view TIT_V_WC_UTILISATEURS as
select 

NOM_UTI     ,
MOT_PAS     ,
LIB_LON     ,
DAT_DER_CON ,
NBR_CON     ,
COD_STA     ,
COD_PRO     ,
NUM_CPT_DEF ,
AUT_ACH     ,
AUT_VEN     ,
MAT_CRE     ,
DAT_CRE     ,
MAT_MOD     ,
DAT_MOD     ,
DAT_JOU_CRE ,
DAT_JOU_MOD ,
NUM_CON     ,
PIN_USR     From wc_utilisateurs@wc_afc

/

