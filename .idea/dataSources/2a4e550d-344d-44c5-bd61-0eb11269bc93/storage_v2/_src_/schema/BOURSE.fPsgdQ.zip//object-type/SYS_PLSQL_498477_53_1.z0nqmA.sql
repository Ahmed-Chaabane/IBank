create TYPE "SYS_PLSQL_498477_53_1"                                                                                                                                                             as object (OPCVM VARCHAR2(30),
DATE_ACTIF DATE,
ACTIF_NET NUMBER(13,3),
BT NUMBER(13,3),
ACT NUMBER(13,3),
EMP NUMBER(13,3),
OPCV NUMBER(13,3),
PLAC NUMBER(13,3));
/

