create FUNCTION          "SOLDE_SICAV_GLB" (P_COD_CPT IN VARCHAR2 ) Return Number Is
CURSOR C IS SELECT val_cod_val,qte_val FROM PORTEFEUILLE WHERE CPT_COD_CPT = P_COD_CPT AND vAL_COd_VAL IN
                         (Select cod_val 
                          from tit_Valeur 
                          Where  CAT_VAl='S' );
W_TRS_SICAV Number(18,3);
V_dat_jou date;
w_cours number;
SOL_SIC number;

BEGIN
   select dat_jou into V_dat_jou from journee;
   FOR V IN C LOOP
    BEGIN
        
                              
                              
        Select nvl(cou_ref,cou_clo) into w_cours from tit_cours_jour where cod_val=v.val_cod_val;
        SOL_SIC := nvl(SOL_SIC,0) + nvl(w_cours*v.qte_val,0);
        exception when others then 
          select COU_ACT_VAL into w_cours 
          from tit_valeur 
          where cod_val=v.val_cod_val;

          SOL_SIC := nvl(SOL_SIC,0) + nvl(w_cours*v.qte_val,0);
    END;
   END LOOP;
   return nvl(SOL_SIC,0);
END;
/

