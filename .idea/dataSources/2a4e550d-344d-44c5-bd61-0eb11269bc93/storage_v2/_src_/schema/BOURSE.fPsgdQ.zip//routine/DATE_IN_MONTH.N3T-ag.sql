create FUNCTION DATE_IN_MONTH 
(
  DATEIN IN DATE  
, OPCVM IN VARCHAR2  
) RETURN DATE AS 
pragma autonomous_transaction;
dateout date;
BEGIN  
  
  select max(dat_ivl) into dateout from SC_VL_NGTREND where alias=OPCVM and dat_ivl <= datein ;
  
  RETURN dateout;
  
END DATE_IN_MONTH;
/

