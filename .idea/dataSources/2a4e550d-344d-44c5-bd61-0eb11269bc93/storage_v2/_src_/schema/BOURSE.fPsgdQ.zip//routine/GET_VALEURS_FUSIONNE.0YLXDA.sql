create FUNCTION           "GET_VALEURS_FUSIONNE" (
 p_nom_uti in varchar
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
/*
fonction pour l'affichage du portefeuille fusionné
*/
OPEN liste FOR 
    select distinct val.cod_val, val.MNE_VAL, 
    decode(nvl(cat_val,'A'),'O', nvl(dern_cou,val.der_cou) , nvl(don.dern_cou,val.DER_COU)  ) , ord_aff
    from wc_valeur val, wc_portefeuille porte, WC_DET_ACCES acc, wc_donne_marche don
    where acc.nom_uti = p_nom_uti and 
      porte.num_cpt= acc.num_cpt and 
      porte.qte_val != 0 and      
      porte.cod_val = val.cod_val and 
      val.cod_isin = don.cod_isin(+)
     order by ord_aff;
  return liste;
end;
/

