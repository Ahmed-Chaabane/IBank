create FUNCTION          "F_TIT_RAMENE_QTE_VENTE" (P_Cod_cpt in Varchar2,
                                P_dat_jou in Date,
                                P_cod_val In Number,
                                P_Ord_enc Out number,
                                P_exe_jrn Out Number ) RETURN Number IS

BEGIN 
  Select greatest( nvl(sum(qte_ord -   (nvl(qte_exe,0))),0) -  sum(decode(nvl(mnt_imp,0),0,0,nvl(qte_exe_jrn,0))),0)  into P_ord_enc
              From ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   CPT_COD_CPT = P_cod_cpt 
                            AND VAL_COD_VAL = P_COD_VAL
                            and sta_cod_sta = 1
                            and nat_ins_ord = 2 ; --- vente 

 /*
  
  Select nvl(sum(qte_ord -   (nvl(qte_exe,0))),0)    into P_ord_enc
              From ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   CPT_COD_CPT = P_cod_cpt 
                            AND VAL_COD_VAL = P_COD_VAL
                            and sta_cod_sta = 1
                            and nat_ins_ord = 2 ; --- vente 
 */
 
        --- ramener les ordres au moment apres leur annulation arrive un execution

        Select  nvl(sum(qte_exe_jrn),0)   into P_exe_jrn
              From ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   CPT_COD_CPT = P_cod_cpt 
                            AND VAL_COD_VAL=P_COD_VAL
                            and sta_cod_sta  in (1,32)
                            and nat_ins_ord = 6 
                            and nvl(mnt_imp,0)=0
                            and dat_sai_en_bou is not null;  --- annul vente
                            
        Select  greatest(nvl(P_ord_enc,0) + nvl(sum(qte_ord -   (nvl(qte_exe,0))),0),0)   into P_ord_enc
              From ORDRE  Where   Trunc(dat_fin)>=  trunc(P_dat_jou)
                            and   CPT_COD_CPT = P_cod_cpt 
                            AND VAL_COD_VAL=P_COD_VAL
                            and sta_cod_sta in (1,32)
                            and nat_ins_ord = 6
                            and nvl(mnt_imp,0)=0 
                            and dat_sai_en_bou  is null;  --- annul vente*/
                            
                            
                            
Return 0;                            
                            
END;
/

