create PROCEDURE ramene_typ_compte_com_b(w_cod_cpt in varchar2,x_typ_cpt out varchar2,
                x_err out number ,x_reponse out char) IS
BEGIN

  select typ_com_cod_typ_cpt into x_typ_cpt 
  from compte 
  where cod_cpt =w_cod_cpt;

Exception
    when no_data_found then
      x_err :=1;
      x_reponse := 'Compte Inexistant N° Compte='||ltrim(rtrim(w_cod_cpt));

END;

/

