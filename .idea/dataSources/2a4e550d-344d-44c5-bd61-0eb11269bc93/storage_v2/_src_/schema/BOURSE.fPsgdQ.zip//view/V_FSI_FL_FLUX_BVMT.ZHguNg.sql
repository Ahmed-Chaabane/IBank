create view V_FSI_FL_FLUX_BVMT as
select
 DAT_MSG , NUM_ORD , FLUX_MSG, COD_MSG , COD_STA , COD_ISIN,
 NUM_LOT ,  NUM_TRADE,     EXECUTION_ID from fl_flux_bvmt@ldb_fsi
/

