create view TIT_V_MDGBVMT_INSTRUMENT as
Select  NBTITREADMIS,
        VALEURNOMINAL,
        CODEISIN
 from  instrument@mdg_bvmt
/

