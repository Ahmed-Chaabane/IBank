create FUNCTION   F_TIT_RAMENE_DET_TARIF_INT  (P_Cod_cpt in varchar2,
                     P_cod_pro_tar In varchar2,
                     P_cod_ope In varchar2,
                     P_cod_tar out varchar2,
                     P_lib_tar out varchar2,
                     P_typ_tar out varchar2 , --- fix par tanche ,forfaitaire
                     P_lib_typ_tar out varchar2 , --- fix par tanche ,forfaitaire
                     P_val_tar Out number,
                     P_mnt_min Out number,
                     P_mnt_max out number ) return Number  IS

 w_libelle varchar2(50);
 v_cod_tar number;
  --- (typ_cou,1,' Taux Fixe',2,' Taux par Tranche',3,' Forfaitaire') 
begin
 
 
 
 
 
 
  
   begin
    select cod_tar into v_cod_tar from comm_operation   where  ben_com='I' and ope_cod_ope = P_cod_ope
                   and  nvl(cpt_cod_cpt,'-5549')=P_cod_cpt;
    exception 
       when no_data_found then
            begin
             select cod_tar into v_cod_tar from tit_det_profil_tarif where cod_pro_tar=P_cod_pro_tar
                    and cod_ope=P_cod_ope and ben_com='I';
            exception
            	  when others then return 0;
             end ;
    when others then return -1 ;
  end;
    
    if v_cod_tar is null then 
       return 0 ;
    end if;
    P_cod_tar :=  v_cod_tar;

   ------------  détail tarif 
     Begin
       select ' '||lib_tar,typ_cou,decode(typ_cou,1,' Taux Fixe',2,' Taux par Tranche',3,' Forfaitaire'),
              decode(typ_cou,1,tau_tar/1000,3, mnt_for ),mnt_min,mnt_max
              into P_lib_tar,P_typ_tar,P_lib_typ_tar,p_val_tar,P_mnt_min,P_mnt_max from TARIF_STANDARD 
       Where cod_tar= V_cod_tar;
     Exception
       When others then return - 1;
     End;
  
  return 0;

end;
/

