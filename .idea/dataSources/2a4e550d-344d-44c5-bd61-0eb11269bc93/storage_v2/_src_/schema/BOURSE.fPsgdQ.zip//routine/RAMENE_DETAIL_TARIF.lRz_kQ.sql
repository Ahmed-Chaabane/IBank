create Function Ramene_detail_Tarif(P_Cod_cpt in varchar2,
                     P_cod_ope In varchar2,
                     P_cod_tar out number,
                     P_lib_tar out varchar2,
                     P_typ_tar out varchar2 , --- fix par tanche ,forfaitaire
                     P_val_tar Out number,
                     P_mnt_min Out number,
                     P_mnt_max out number ) return Number  IS

w_libelle varchar2(50);
v_cod_tar number;
begin
 
   begin
    select cod_tar into v_cod_tar from comm_operation
            where  ben_com='I' and ope_cod_ope = P_cod_ope
                   and  nvl(cpt_cod_cpt,'-5549')=P_cod_cpt;
    exception 
       when no_data_found then
        begin
           select cod_tar into v_cod_tar 
                  from comm_operation
           where  ben_com='I'
                  and ope_cod_ope =P_cod_ope
                  and  cpt_cod_cpt is null;

           exception when no_data_found then
                  null;
         end;
      when others then Null ;
    end;
    if v_cod_tar is null then 
       return 0 ;
    end if;
    P_cod_tar :=  v_cod_tar;

   ------------  détail tarif 
     Begin
       select ' '||lib_tar,decode(typ_cou,1,' Taux Fixe',2,' Taux par Tranche',3,' Forfaitaire'),
              decode(typ_cou,1,tau_tar/1000,3, mnt_for ),mnt_min,mnt_max
              into P_lib_tar,P_typ_tar,p_val_tar,P_mnt_min,P_mnt_max from TARIF_STANDARD 
       Where cod_tar= P_cod_tar;
     Exception
       When others then return - 1;
     End;
  
  return 0;
  end;
/

