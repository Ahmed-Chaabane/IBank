create FUNCTION           "GET_PORTEFEUILLE" (
 p_num_cpt in varchar
)
return TYPES.ref_cursor
as
liste types.ref_cursor;
begin
OPEN liste FOR 
      /* SELECT 
            substr(nvl(MNE_VAL,LIB_VAL),1,30) AS MNE_VAL,
            val.cod_val AS COD_VAL,
            CAT_VAL,
            QTE_VAL,            
            nvl(QTE_BLO_VAL,0) AS QTE_BLO_VAL,  
            COU_ACQ, 
            COU_ACQ_NET, 
            DER_COU, 
            MNT_COM
        FROM WC_VALEUR val, WC_PORTEFEUILLE porte 
        WHERE val.COD_VAL = porte.COD_VAL and porte.NUM_CPT = p_num_cpt and QTE_VAL !=0 
        ORDER BY ORD_AFF, CAT_VAL;   */
       
        SELECT 
            substr(nvl(MNE_VAL,LIB_VAL),1,30) AS MNE_VAL,
            val.cod_val AS COD_VAL,
            CAT_VAL,
            QTE_VAL,            
            nvl(QTE_BLO_VAL,0) AS QTE_BLO_VAL,  
            COU_ACQ,
            COU_ACQ_NET, 
            decode(nvl(cat_val,'A'),'O',val.nominal,nvl(don.dern_cou,DER_COU)) as DER_COU, 
            MNT_COM
        FROM WC_VALEUR val, WC_PORTEFEUILLE porte, wc_donne_marche don
        WHERE 
        porte.NUM_CPT = p_num_cpt and  
        val.COD_VAL = porte.COD_VAL and 
                QTE_VAL !=0 and
        don.cod_isin (+) = val.cod_isin 
        ORDER BY ORD_AFF, CAT_VAL;       
      return liste;
end;
/

