create FUNCTION           "INSER_NEWS" (                          P_LIB_CRT In Varchar2,
                            P_LIB_LON In Varchar2) Return integer Is  

v_num_ope number;
Begin

	begin
	  if(trim(P_LIB_LON) is not null) then
	  select max(num_ope) into v_num_ope from wc_news;
	  
	  insert into wc_news(NUM_OPE, DAT_DEB_AFF, DAT_FIN_AFF, LIB_CRT, LIB_LON, ORD_AFF, COD_STA )
	  values(v_num_ope+1,sysdate, sysdate+1,INITCAP(trim(replace(replace(P_LIB_CRT,'<SUITE>',''),'@',' '))),INITCAP(P_LIB_LON),1,'10');
	end if;
	exception when others then
	   return -1;
	end;

 Return 10;
END;
/

