create view TIT_V_WC_DET_ACCES as
select 

NOM_UTI ,
NUM_CPT ,
DAT_DEB ,
DAT_FIN ,
COD_STA ,
AUT_ACH ,
AUT_VEN ,
DAT_JOU ,
MAT_CRE ,
DAT_CRE ,
MAT_MOD ,
DAT_MOD 

    From wc_det_acces@wc_afc

/

