create TYPE "SYS_PLSQL_498470_9_1"                                                                                                                                                             as object (OPCVM VARCHAR2(30),
DATE_VL DATE,
VL NUMBER(13,3),
DATE_VL_AVANT DATE,
VL_AVANT NUMBER(13,3));
/

