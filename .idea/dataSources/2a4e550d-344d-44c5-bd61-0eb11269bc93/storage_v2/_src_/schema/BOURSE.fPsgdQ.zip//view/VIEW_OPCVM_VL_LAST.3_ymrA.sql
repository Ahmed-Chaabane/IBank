create view VIEW_OPCVM_VL_LAST as
select 
V.alias, V.dat_ivl,V.nbre_act_ivl,V.nbre_jour_ivl,V.vl_ivl,V.liquidite,V.dat_comp,V.ide_opcvm, P.actif_net from
(select 
alias, dat_ivl,nbre_act_ivl,nbre_jour_ivl,vl_ivl,liquidite,dat_comp,ide_opcvm from  sc_vl_ngtrend
where dat_ivl = 
(select max(dat_ivl) from sc_vl_ngtrend)) V join
(select distinct alias,actif_net,dat_prtf from sc_prtf_ngtrend) P on V.alias=P.alias and V.dat_ivl=P.dat_prtf
/

