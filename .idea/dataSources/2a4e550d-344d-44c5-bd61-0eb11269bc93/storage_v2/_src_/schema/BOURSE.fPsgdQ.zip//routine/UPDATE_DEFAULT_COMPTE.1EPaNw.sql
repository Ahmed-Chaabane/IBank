create PROCEDURE           "UPDATE_DEFAULT_COMPTE" (
 p_num_cpt_def in varchar,
 p_nom_uti in varchar
)
as
begin
    UPDATE WC_UTILISATEURS set NUM_CPT_DEF = p_num_cpt_def WHERE NOM_UTI = p_nom_uti;
end;
/

