create PROCEDURE           "ABANDONNER_ORDRE" (
 p_num_ordre in number,
 p_nom_uti in varchar
)
as
---- quand l'ordre crée n'a pas été encore transmis à l'afc
begin
    UPDATE WC_ORDRE 
    set COD_STA = '4', USE_MOD=p_nom_uti, DAT_MOD=sysdate, ORIGINE_MOD='W',COD_STA_TRS='30'
    WHERE NUM_ORD = p_num_ordre;
end;
/

