create PROCEDURE ges_comm_tranche_com_b(w_cod_com in number ,w_param_cou in number,
          w_mnt_opr in number,x_mnt_com out number,
          x_err out number,x_reponse out char) IS
    L_mnt_opr    number:=w_mnt_opr ;
L_tau_tranche    number;
    L_bor_min    number(18,3);
    L_bor_max    number(18,3);
    L_tranche    number;
      L_recup    number:=0;

BEGIN
  Loop
     Exit when L_mnt_opr = 0 ;
   Begin
     select nvl(tau_com_bou,0)/1000,bor_min,bor_max into L_tau_tranche,L_bor_min,L_bor_max
            from detail_com_bourse
            where cod_com=w_cod_com  and ide_par_com=w_param_cou
            and L_mnt_opr between bor_min and bor_max;


     if L_bor_min = 0
        then
        L_tranche := L_mnt_opr + L_recup;
        L_mnt_opr := L_Bor_min ;


     else  
        L_tranche := (L_mnt_opr - L_bor_min) + L_Recup;
        L_recup := 1/1000;
        L_mnt_opr := L_Bor_min - L_recup;

     End if;
     X_mnt_com := round(nvl(x_mnt_com,0),3) +  round((L_tranche*L_tau_tranche),3);


  exception
    when no_data_found then
    x_err :=1;
    x_reponse :='Attention (Detail Comm Bourse)='||ltrim(rtrim(w_cod_com))||
                '-'||ltrim(rtrim(to_char(w_param_cou)))||' Inéxistant !!!!';
    return;
    when too_many_rows then
     
    x_err :=1;
    x_reponse :='Attention (Detail Comm Bourse)='||ltrim(rtrim(w_cod_com))||
                '-'||ltrim(rtrim(to_char(w_param_cou)))||
               ' Chevauche avec 2 Bornes!!!!';
    return;
  end;
 end loop;

END;

/

