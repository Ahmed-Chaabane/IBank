create PROCEDURE           "ANNULER_ORDRE" (
 p_num_ordre in number,
 p_nom_uti in varchar
)
as
   v_num_ord varchar2(7);
begin
    UPDATE WC_ORDRE 
    set COD_STA = '3', USE_MOD=p_nom_uti, DAT_MOD=sysdate, ORIGINE_MOD = 'W',COD_STA_TRS='30'
    WHERE NUM_ORD = p_num_ordre; --1 --19267
    
    select ANNEE_SEANCE || ltrim(to_char(wc_seq_ordre.nextval, '00000')) into v_num_ord  from wc_param_logiciel;
    begin
    insert into WC_ORDRE(ORIGINE,SEN_ORD,NUM_ORD_BO,DAT_ORD_BO,NUM_ORD,DAT_FIN,QTE_ORD,QTE_EXE,QTE_DEV,NUM_CPT,COD_VAL,TYP_LIMITE,COURS,USE_CRE,DAT_CRE,COD_STA,NAT_INS_OP,DAT_DEB,EST_ORD,COD_STA_BO,QTE_EXE_JRN,COD_STA_TRS,IDE_ORD_INI, NUM_ORD_INI,ORD_WEB_INI,mnt_imp) 
      select 'W',SEN_ORD,null,null,v_num_ord,---num ord composé
      DAT_FIN,QTE_ORD,QTE_EXE,QTE_DEV,NUM_CPT,COD_VAL,TYP_LIMITE,COURS,p_nom_uti,sysdate,'1',
      case SEN_ORD when 1 then 4 else 6 end,---nature
      DAT_DEB,EST_ORD,nvl(COD_STA_BO,'4'),QTE_EXE_JRN,'45',-- à transmettre
      IDE_ORD, --- NUM_ORD_INI
      NUM_ORD_BO,
      NUM_ORD,mnt_imp
    from WC_ORDRE
    WHERE NUM_ORD = p_num_ordre;
    exception
    when others then
      null;
    end;
end;
/

