create PROCEDURE          "GESTION_COMM_BOURSE" (P_cod_ope in varchar2,
                              P_cod_cpt in varchar2,
                              P_typ_tra in varchar2,
                              P_num_evt in number,
                              P_cod_val in NUMBER,
                              P_mnt_ope in number,
                              P_dat_tra in date,
                              P_dat_jou in date,
                              P_mnt_com in out number,
                              P_mnt_tva in out number,
                              P_flag in varchar2,
                              P_err in out number,
                              P_reponse in out VARCHAR2) IS

 Cursor c_1(Pr_cod_cpt in varchar2,pr_source varchar2,p_cod_pro_tar varchar2) is
          select OPE_COD_OPE,BEN_COM,COD_TAR   /* + index(comm_operationidx_commope)*/
          from comm_operation 
          where pr_source = 'E'
              and  ope_cod_ope=P_cod_ope 
              and  ben_com='B'
              and  nvl(cpt_cod_cpt,'-5549')=Pr_cod_cpt
      union 
          select COD_OPE,BEN_COM,COD_TAR  /* + index(comm_operationidx_commope)*/
          from tit_det_profil_tarif  where pr_source = 'S'
                                and  COD_OPE=P_cod_ope 
                                and  cod_pro_tar = p_cod_pro_tar 
                                and  ben_com='B' ;


        rec   c_1%rowtype;
  V_cod_tar   number(10);
  V_tau_tar   number;
  V_mnt_min   number(18,3);
  v_mnt_max   number(18,3);
  V_mnt_com   number(18,3):=0;
  V_mnt_tva   number(18,3):=0;
  V_mnt_for   number(18,3);
  Vp_cod_cpt  varchar2(20):='-5549'; -- replca enull <---> tarif std
      v_nbre  Number(4);
  ---------------------
   V_source   varchar2(1);
  v_profile   varchar2(10);
  v_cod_pro   varchar2(10);     
BEGIN
  P_mnt_com:=0;
  P_mnt_tva :=0;
  Select count(*) into v_nbre from comm_operation where Ope_cod_ope=P_cod_ope ---- and ben_com='B' and
         and cpt_cod_cpt = P_cod_cpt;
         
  if Nvl(V_nbre,0) > 0 then         
  	 Vp_cod_cpt := P_cod_cpt;
     V_source := 'E';
   else            
        V_source:='S';
        Begin
          select cod_tar_ach into v_profile from compte where cod_cpt=P_cod_cpt;
          begin
               select COD_PRO_TAR into v_cod_pro    from tit_operation_profil_tarif 
                      where COD_PRO_TAR=v_profile and cod_ope=p_cod_ope;     
          exception
              when no_data_found then v_cod_pro:='0'; -- le standart s'il existe
          end;  	 
        exception
            when others then v_cod_pro:='0'; -- le standart s'il existe
        end; 
  End if;
  
  
  open c_1(Vp_cod_cpt,v_source,v_cod_pro);
  loop
   fetch C_1 into rec;
   exit when C_1%notfound;
   --- ramene condition faveur sinon standard


   begin
      Ramene_detail_com_b(P_cod_ope,P_typ_tra,P_dat_tra,P_dat_jou,P_num_evt,rec.cod_tar,
            P_mnt_ope,P_cod_cpt,P_cod_val,V_mnt_com,V_mnt_tva,P_flag,
            P_err,P_reponse);
            P_mnt_com := round(nvl(V_mnt_com,0),3);
            P_mnt_tva := round(nvl(V_mnt_tva,0),3);

    exception
             when no_data_found then         
             P_err:=1;
             P_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(P_cod_ope))||'-'||
                          ltrim(rtrim(P_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Inéxistante  !!!!';
                return;
             when too_many_rows then
             P_err :=1;
             P_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(P_cod_ope))||'-'||
                          ltrim(rtrim(P_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Duppliqué !!!!';
               return;
                      
  end;
  end loop;
  close c_1;

END;
/

