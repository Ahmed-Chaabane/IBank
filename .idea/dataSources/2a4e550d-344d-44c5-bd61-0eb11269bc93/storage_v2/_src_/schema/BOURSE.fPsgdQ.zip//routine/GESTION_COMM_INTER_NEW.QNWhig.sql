create PROCEDURE          "GESTION_COMM_INTER_NEW" (P_cod_ope in varchar2,P_num_evt in number,P_cod_cpt in varchar2,
          P_mnt_ope in number,P_dat_tra in date,P_dat_jou in date,
          P_mnt_com in out number,P_mnt_tva in out number,P_flag in varchar2,
          P_err in out number,P_reponse out varchar2) IS
          
  Cursor C_1(Pr_cod_cpt varchar2) is
          select OPE_COD_OPE,BEN_COM,COD_TAR,CPT_COD_CPT  /* + index(comm_operationidx_commope)*/
          from comm_operation  where ope_cod_ope=P_cod_ope  
                                and   ben_com='I'
                                and  nvl(cpt_cod_cpt,'-5549')=Pr_cod_cpt ;
         


        rec   c_1%rowtype;
  v_cod_tar   number(10);
  V_mnt_tva   number(18,3);
  V_tau_tva   number;
  V_tau_tar   number;
  V_mnt_min   number(18,3);
  V_mnt_max   number(18,3);
  V_typ_cou   number;
  V_mnt_for   number(18,3);
  V_mnt_com   number(18,3);
  V_cod_tva   varchar2(5);
  V_Cod_cpt   varchar2(20):='-5549';  ---remplace null --- > le standard
     V_nbre   Number(3);
BEGIN

   P_mnt_tva := 0;
   P_mnt_com := 0;

   Select count(*) into v_nbre from comm_operation where Ope_cod_ope=P_cod_ope and ben_com='I' and cpt_cod_cpt=P_cod_cpt;
   
   if nvl(v_nbre,0) != 0 then
   	  V_Cod_cpt  := P_cod_cpt;
   End if;

  open C_1(V_cod_cpt);
  loop
   fetch c_1 into rec;
   exit when C_1%notfound;
   --- ramene condition faveur sinon standard
   V_mnt_com := 0;
   V_mnt_tva := 0;

   begin
       select nvl(tau_tar,0)/1000,mnt_min,mnt_max,typ_cou,mnt_for,cod_tva into
              V_tau_tar,V_mnt_min,V_mnt_max,V_typ_cou,V_mnt_for,V_cod_tva
       from tarif_standard
       where cod_tar =rec.cod_tar;

 
      If  V_typ_cou =1 then  --- taux
         V_mnt_com := P_mnt_ope * V_tau_tar ;
         if V_mnt_com < nvl(V_mnt_min,0)
            then
            V_mnt_com := nvl(V_mnt_min,0);
         end if;
         if V_mnt_com > nvl(V_mnt_max,0)
            then
            V_mnt_com := nvl(V_mnt_max,0);
         end if;
      Elsif V_typ_cou = 3 Then  --- forfaitaire
          V_mnt_com := nvl(V_mnt_for,0);
      Elsif V_typ_cou = 2 then  --- / tranche
          V_mnt_com := 0 ;
          ges_comm_inter_tranche(rec.cod_tar,P_mnt_ope,V_mnt_com,
                                 P_err,P_reponse);
          if P_err is not null then return; end if;

          if V_mnt_com < nvl(V_mnt_min,0)
             then
             v_mnt_com := nvl(V_mnt_min,0);
          end if;
          if v_mnt_com > nvl(V_mnt_max,0)
             then
             v_mnt_com := nvl(v_mnt_max,0);
          end if;
        
          	
       end if ;  --- fin case
      --- Traite Tva Commission 
   ramene_tau_tva(V_cod_tva,P_dat_tra,P_cod_cpt,V_tau_tva,P_err,P_reponse);
   if P_err is not null then  return; end if; 
      V_mnt_tva := nvl(V_mnt_com,0) * V_tau_tva;
   if P_flag ='T' and nvl(v_mnt_com,0)!=0
      then
      begin
      -- insertion dans la table trace_commission
      insert into trace_commission(num_evt,dat_jou,dat_tra_evt,cod_cpt,
              ben_comm,cod_com,cod_sta,mnt_ope,mnt_com,mnt_tva,ope_cod_ope) values
                (P_num_evt,P_dat_jou,P_dat_tra,P_cod_cpt,
                'I',rec.cod_tar,1,P_mnt_ope, round(nvl(V_mnt_com,0),3), round(nvl(V_mnt_tva,0),3),P_cod_ope);
         --- actualisation du compte
                 exception
            when others then
                 P_err :=2;
                 P_reponse :=' Erreur TRACE_COM :'||sqlerrm;

                 return;
         end;
   end if;


   P_mnt_tva := round(nvl(P_mnt_tva,0),3) + round(nvl(V_mnt_tva,0),3);
   P_mnt_com := round(nvl(P_mnt_com,0),3) + round(nvl(V_mnt_com,0),3);
      
    exception
             when no_data_found then         
             P_err:=1;
             P_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(P_cod_ope))||'-'||
                          ltrim(rtrim(P_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Inéxistante  !!!!';
             return;
             when too_many_rows then
             P_err:=1;
             P_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(P_cod_ope))||'-'||
                          ltrim(rtrim(P_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Duppliqué !!!!';
             return;
         
  end;
  end loop;
  close c_1;
END;
/

