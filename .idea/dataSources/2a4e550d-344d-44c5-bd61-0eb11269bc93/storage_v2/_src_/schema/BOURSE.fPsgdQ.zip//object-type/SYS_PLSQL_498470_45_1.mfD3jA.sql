create TYPE "SYS_PLSQL_498470_45_1"                                                                                                                                                             as table of PARTAGE."SYS_PLSQL_498470_9_1";
/

