create FUNCTION           "GET_OPCVM" RETURN TYPES.ref_cursor
as
liste types.ref_cursor;
begin

OPEN liste FOR 

  SELECT
     substr(nvl(MNE_VAL,LIB_VAL),1,30) AS MNE_VAL,
     DER_COU,
     DAT_DER_COU
  FROM WC_OPCVM opcvm, WC_VALEUR val
  WHERE opcvm.COD_VAL = val.COD_VAL
  ORDER BY ltrim(mne_val);
  
  
RETURN liste;
end;
/

