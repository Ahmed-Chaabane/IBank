create FUNCTION           "CALCUL_ESTIM" (                             p_NUM_CPT in varchar2,
                               p_COD_VAL in number,
                            p_typ_limite in number,
                                 p_COURS in number,
                               p_QTE_ORD in number,
                            p_NAT_INS_OP in number,
                               p_typ_cli in varchar2) Return Number Is  --- S imule  , T ransactionelle "insert" ) IS;
                            

      B_TOT  Number;
  v_EST_ORD  number;
Begin
   --- calcul montant operation
   if(p_typ_limite = 1) then --- si ordre limité                            
     v_EST_ORD := p_cours * p_QTE_ORD;
   else                      --- si ordre prix marché ou atp
    begin
       select DERN_COU into v_EST_ORD
       from wc_donne_marche don, wc_valeur val
       where val.cod_isin = don.cod_isin and val.cod_val = p_COD_VAL;
    EXCEPTION 
    when others then 
      v_EST_ORD := 0;
    end;
    v_EST_ORD := v_EST_ORD  * p_QTE_ORD;   
   end if;
    --- calcul commissions
    B_TOT :=  f_tit_calcul_comm(p_NAT_INS_OP,
                            p_NUM_CPT,
                            null,
                            p_COD_VAL,
                            'O',
                            v_EST_ORD,
                            trunc(sysdate),
                            trunc(sysdate),
                            'S',
                            null, 
                            B_TOT,B_TOT,B_TOT,B_TOT) ;  
  B_TOT := nvl(B_TOT,0);
  if(p_typ_cli = '2') then 
       v_EST_ORD :=0;
  end if;              
  --- calcul estimation ordre
 if p_NAT_INS_OP = 2  then -- vente
     return v_EST_ORD - B_TOT ;
	else -- achats
     return -(v_EST_ORD +B_TOT );
	end if; 
end;
/

