create FUNCTION           "GET_MESSAGES" (P_Cod_err in int) return varchar2  IS

v_lib_mes varchar2(1000);
begin
 
  select lib_mes into v_lib_mes from wc_messages where cod_mes = P_Cod_err;
  
  return v_lib_mes;
end;
/

