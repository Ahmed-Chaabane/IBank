create trigger ACTUALISE_ORDRE
    after insert or update of DAT_DEB,DAT_FIN,EST_ORD,NAT_INS_ORD,NUM_ORD_MOD,QTE_EXE,QTE_ORD,DAT_SAI_EN_BOU,VAL_COD_VAL,CPT_COD_CPT,STA_COD_STA,TYP_ORD_COD_TYP_ORD,COU_LIM,AVS_PAY_ORD,IDE_ORD,QTE_DEV,QTE_EXE_JRN,MNT_IMP,OLD_QTE_EXE
    on ORDRE
    for each row
BEGIN
    IF   INSERTING and :new.origine='B' then
        insert into wc_protocole@WC_AFC(origine,dat_jou,cod_ins,num_ope,dat_cre,cod_cpt,
                                        cod_tar_inter,cod_tar_bvmt,cod_ope,nom_uti,cod_sta_env,
                                        num_lot,cod_val,cou_ref,qte_val,dat_ord,num_ord,fam_ope,
                                        texte_1,date_2,date_3,mot_pas,mnt_com,mnt_tva,cod_sta,montant_1,com_bou,
                                        montant_2,tva_bou,date_4,montant_7,montant_8)

        values ('B',:new.dat_deb,'160',wc_seq_protocole.nextval@WC_AFC,:new.dat_mod,:new.cpt_cod_cpt,
                :new.num_ord,:new.qte_dev,:new.TYP_ORD_COD_TYP_ORD,
                :new.usr_mod,:new.sta_cod_sta,
                :new.qte_exe,:new.val_cod_val,:new.cou_lim,:new.qte_ord,
                :new.dat_deb,:new.num_ord,:new.sen_ord,
                :new.nat_ins_ord,:new.dat_fin,:new.dat_deb,'I',:new.ord_int,
                :new.NUM_ORD_MOD,'1',:new.est_ord,:new.qte_exe_jrn,:new.ide_ord,:new.ide_ini_ord,
                :new.dat_sai_en_bou,:new.mnt_imp,:new.old_qte_exe) ;
    END IF;
    IF UPDATING  and nvl(:new.origine_mod,'B')='B' THEN
        insert into WC_AFC (origine,dat_jou,cod_ins,num_ope,dat_cre,cod_cpt,
                                         cod_tar_inter,cod_tar_bvmt,cod_ope,nom_uti,cod_sta_env,
                                         num_lot,cod_val,cou_ref,qte_val,dat_ord,num_ord,fam_ope,
                                         texte_1,date_2,date_3,mot_pas,mnt_com,mnt_tva,cod_sta,montant_1,com_bou,montant_2,tva_bou,
                                         montant_3,lib_evt,date_4,montant_5,montant_6,montant_7,montant_8)

        values
            ('B',:new.dat_deb,'160',wc_seq_protocole.nextval@WC_AFC,:new.dat_mod,:new.cpt_cod_cpt,
             :new.num_ord,:new.qte_dev,:new.TYP_ORD_COD_TYP_ORD,
             :new.usr_mod,:new.sta_cod_sta,
             :new.qte_exe,:new.val_cod_val,:new.cou_lim,:new.qte_ord ,
             :new.dat_deb,:new.num_ord,:new.sen_ord,
             :new.nat_ins_ord,:new.dat_fin,:new.dat_deb,'M',:old.ord_int,:old.num_ord_mod,
             '1',:new.est_ord,:new.qte_exe_jrn,:new.ide_ord,:new.ide_ini_ord,:old.est_ord,
             :new.origine_mod,  :new.dat_sai_en_bou,:new.old_exe_jrn,:old.ide_ord,:new.mnt_imp,:new.old_qte_exe) ;
    END IF;
END;
/

