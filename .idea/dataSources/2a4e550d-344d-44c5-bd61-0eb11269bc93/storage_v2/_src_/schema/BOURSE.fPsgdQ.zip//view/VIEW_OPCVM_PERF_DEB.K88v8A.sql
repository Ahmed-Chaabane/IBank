create view VIEW_OPCVM_PERF_DEB as
SELECT DISTINCT j.alias,
    j.DAT_IVL,
    j.vl_ivl,
    v.dat_ivl,
    v.vl_ivl
  FROM sc_vl_ngtrend j  
  JOIN sc_vl_ngtrend v
  ON v.dat_ivl = j.DAT_IVL_DEB_AN
  AND v.alias  = j.alias
/

