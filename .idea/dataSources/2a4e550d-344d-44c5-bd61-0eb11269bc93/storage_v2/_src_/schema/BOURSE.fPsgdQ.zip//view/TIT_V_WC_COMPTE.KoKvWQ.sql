create view TIT_V_WC_COMPTE as
select 

PIN_CLI  ,--                      NOT NULL VARCHAR2(20)
NUM_CPT  ,--                               VARCHAR2(20)
LIB_CPT   ,--                     NOT NULL VARCHAR2(100)
SLD_ESP     ,--                   NOT NULL NUMBER(18,3)
SLD_SIC       ,--                 NOT NULL NUMBER(18,3)
SLD_ACH         ,--               NOT NULL NUMBER(18,3)
CHQ_ENC      ,--                  NOT NULL NUMBER(18,3)
SLD_BLO      ,--                  NOT NULL NUMBER(18,3)
SLD_CMP      ,--                  NOT NULL NUMBER(18,3)
NUM_CPT_MAN  ,--                           VARCHAR2(20)
NUM_CPT_GES  ,--                           VARCHAR2(20)
TYP_CPT      ,--                           VARCHAR2(5)
DAT_OUV_CPT  ,--                           DATE
DAT_DER_CHA  ,--                           DATE
DAT_OUV_WEB  ,--                           DATE
CON_SIC      ,--                           VARCHAR2(1)
EXO_TVA      ,--                           VARCHAR2(1)
DAT_DEB_TVA   ,--                          DATE
DAT_FIN_TVA     ,--                        DATE
DAT_CLO_CPT     ,--                        DATE
LIB_CPT_EXT_1   ,--                        VARCHAR2(50)
LIB_CPT_EXT_2   ,--                        VARCHAR2(50)
IND_CAT_AVO     ,--                        VARCHAR2(1)
COD_GES         ,--                        VARCHAR2(20)
COD_PRO_TAR      --                       VARCHAR2(10)

    From wc_compte@wc_afc

/

