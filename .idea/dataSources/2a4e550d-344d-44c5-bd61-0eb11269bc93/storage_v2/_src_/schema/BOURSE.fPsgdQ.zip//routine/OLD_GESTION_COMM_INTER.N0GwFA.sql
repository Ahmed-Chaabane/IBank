create PROCEDURE          "OLD_GESTION_COMM_INTER" (w_cod_ope in varchar2,w_num_evt in number,w_cod_cpt in varchar2,
          w_mnt_opr in number,w_dat_tra in date,w_dat_jou in date,
          tot_mnt_com in out number,x_tot_mnt_tva in out number,w_flag in varchar2,
          x_err in out number,x_reponse out char) IS
  cursor c1 is
          select OPE_COD_OPE,BEN_COM,COD_TAR,CPT_COD_CPT  /* + index(comm_operationidx_commope)*/
         from comm_operation
         where ope_cod_ope=w_cod_ope  and   ben_com='I'
         and  nvl(cpt_cod_cpt,'-5549')=w_cod_cpt
union
         select OPE_COD_OPE,BEN_COM,COD_TAR,CPT_COD_CPT  /* + index(comm_operationidx_commope)*/
         from comm_operation
         where ope_cod_ope=w_cod_ope  and ben_com='I'
         and  cpt_cod_cpt is null and not exists(select 1 from
           comm_operation where ope_cod_ope=w_cod_ope and ben_com in ('I','B') and
             nvl(cpt_cod_cpt,'gff14')=w_cod_cpt);
         


  rec   c1%rowtype;
  z_cod_tar   number(10);
  z_mnt_tva   number(18,3);
  x_tau_tva   number;
  z_tau_tar   number;
  z_mnt_min   number(18,3);
  z_mnt_max   number(18,3);
  z_typ_cou   number;
  z_mnt_for   number(18,3);
  x_mnt_com   number(18,3);
  z_cod_tva   varchar2(5);


BEGIN

   x_tot_mnt_tva := 0;
   tot_mnt_com := 0;

  open c1;
  loop
   fetch c1 into rec;
   exit when c1%notfound;
   --- ramene condition faveur sinon standard
   x_mnt_com := 0;
   z_mnt_tva := 0;

   begin
       select nvl(tau_tar,0)/1000,mnt_min,mnt_max,typ_cou,mnt_for,cod_tva into
              z_tau_tar,z_mnt_min,z_mnt_max,z_typ_cou,z_mnt_for,z_cod_tva
       from tarif_standard
       where cod_tar =rec.cod_tar;

      if z_typ_cou = 1
         then
         x_mnt_com := w_mnt_opr * z_tau_tar ;
         if x_mnt_com < nvl(z_mnt_min,0)
            then
            x_mnt_com := nvl(z_mnt_min,0);
         end if;
         if x_mnt_com > nvl(z_mnt_max,0)
            then
            x_mnt_com := nvl(z_mnt_max,0);
         end if;
      elsif z_typ_cou = 3
          then
          x_mnt_com := nvl(z_mnt_for,0);
      elsif z_typ_cou=2  --- / tranche
          then
          x_mnt_com := 0 ;
          ges_comm_inter_tranche(rec.cod_tar,w_mnt_opr,x_mnt_com,
                                 x_err,x_reponse);
          if x_err is not null then return; end if;

          if x_mnt_com < nvl(z_mnt_min,0)
             then
             x_mnt_com := nvl(z_mnt_min,0);
          end if;
          if x_mnt_com > nvl(z_mnt_max,0)
             then
             x_mnt_com := nvl(z_mnt_max,0);
          end if;
        end if;
      --- Traite Tva Commission 
   ramene_tau_tva(z_cod_tva,w_dat_tra,w_cod_cpt,x_tau_tva,x_err,x_reponse);
   if x_err is not null then  return; end if; 
   z_mnt_tva := nvl(x_mnt_com,0) * x_tau_tva;
   if w_flag ='T' and nvl(x_mnt_com,0)!=0
      then
      begin
      -- insertion dans la table trace_commission
      insert into trace_commission(num_evt,dat_jou,dat_tra_evt,cod_cpt,
              ben_comm,cod_com,cod_sta,mnt_ope,mnt_com,mnt_tva,ope_cod_ope) values
                (w_num_evt,w_dat_jou,w_dat_tra,w_cod_cpt,
                'I',rec.cod_tar,1,w_mnt_opr, round(nvl(x_mnt_com,0),3), round(nvl(z_mnt_tva,0),3),w_cod_ope);
         --- actualisation du compte
                 exception
            when others then
                 x_err :=2;
               
                 x_reponse :=' Erreur TRACE_COM :'||sqlerrm;

                 return;
         end;
   end if;


   x_tot_mnt_tva := round(nvl(x_tot_mnt_tva,0),3) + round(nvl(z_mnt_tva,0),3);
   tot_mnt_com := round(nvl(tot_mnt_com,0),3) + round(nvl(x_mnt_com,0),3);
      
    exception
             when no_data_found then         
             x_err:=1;
             x_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(w_cod_ope))||'-'||
                          ltrim(rtrim(w_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Inéxistante  !!!!';
             return;
             when too_many_rows then
             x_reponse :='Attention (OPE,CPTE,Tarif Inter)='||ltrim(rtrim(w_cod_ope))||'-'||
                          ltrim(rtrim(w_cod_cpt))||'-'||ltrim(rtrim(to_char(rec.cod_tar)))||
                          ' Duppliqué !!!!';
             return;
         
  end;
  end loop;
  close c1;
END;
/

