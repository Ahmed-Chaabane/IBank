create FUNCTION           "CHANGE_PASSWD" (
 p_nom_uti in varchar,
 p_anc_mdp in varchar,
 p_nou_mdp in varchar
)
return int
as
begin

     ---update wc_utilisateurs set mot_pas = p_nou_mdp where nom_uti = p_nom_uti and mot_pas = p_anc_mdp;
     update wc_utilisateurs set mot_pas = create_passwd(p_nou_mdp) where nom_uti = p_nom_uti and mot_pas = create_passwd(p_anc_mdp);
     if(SQL%NOTFOUND) then
      return -1;
    end if;

return 1;
end;
/

