create view VIEW_OPCVM_VAL_PERF as
SELECT distinct m.alias,
    m.DAT_IVL,
    p.actif_net,
    v.vl_ivl,
    vc.dat_ivl,
    vc.vl_ivl,
    vm.dat_ivl,
    vm.vl_ivl,
    vd.dat_ivl,
    vd.vl_ivl,
    va.dat_ivl,
    va.vl_ivl,
    v5a.dat_ivl,
    v5a.vl_ivl
  FROM
    (SELECT MIN(dat_ivl) dat_ivl,
      MIN(dat_ivl_mois) dat_ivl_mois,
      MIN(dat_ivl_deb_an) dat_ivl_deb_an,
      MIN(dat_ivl_an) dat_ivl_an,
      MIN(dat_ivl_5ans) dat_ivl_5ans,
      ALIAS
    FROM sc_vl_ngtrend
    GROUP BY ALIAS,
      extract(MONTH FROM dat_ivl),
      extract(YEAR FROM dat_ivl)
    ) m
  JOIN
    (SELECT MIN(dat_ivl) dat_ivl,ALIAS FROM sc_vl_ngtrend GROUP BY ALIAS
    ) c
  ON c.alias =m.alias
  JOIN sc_vl_ngtrend v
  ON v.dat_ivl = m.dat_ivl
  AND v.alias  =m.alias
  JOIN sc_vl_ngtrend vc
  ON vc.dat_ivl = c.dat_ivl
  AND vc.alias  =c.alias
  LEFT JOIN sc_vl_ngtrend vm
  ON vm.dat_ivl=m.dat_ivl_mois
  AND vm.alias =m.alias
  LEFT JOIN sc_vl_ngtrend vd
  ON vd.dat_ivl=m.dat_ivl_deb_an
  AND vd.alias =m.alias
  LEFT JOIN sc_vl_ngtrend va
  ON va.dat_ivl=m.dat_ivl_an
  AND va.alias =m.alias
  LEFT JOIN sc_vl_ngtrend v5a
  ON v5a.dat_ivl=m.dat_ivl_5ans
  AND v5a.alias =m.alias
  LEFT JOIN
    (SELECT actif_net,
      dat_prtf,
      ALIAS
    FROM sc_prtf_ngtrend
    GROUP BY dat_prtf,
      ALIAS,
      actif_net
    ) p
  ON p.alias     = m.alias
  AND p.dat_prtf = m.dat_ivl
/

